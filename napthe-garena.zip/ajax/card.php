<?php



$username = $_POST['username'];
$card_type = $_POST['card_type'];
$card_amount = $_POST['card_amount'];
$serial = $_POST['serial'];
$pin = $_POST['pin'];
$tranid = 'thanhmew22'.rand(10000,999999);
$partner_id = '9327651561';
$partner_key = '33c9e85b437bb59cbd2b8568f9f3494b';
if( !$card_amount || !$pin || !$card_type || !$serial){
    die ('<script>Swal.fire("Thông báo", "Vui lòng nhập đủ thông tin", "error")</script>');
}

$data = array(
    'telco' => $card_type,
    'code' => $pin,
    'serial' => $serial,
    'amount' => $card_amount,
    'request_id' => $tranid,
    'partner_id' => $partner_id,
    'sign' => md5($partner_key . $pin . $serial),
    'command' => 'charging'
);
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => 'http://trumthe.vn/chargingws/v2?'.http_build_query($data),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
    ],
]);

$response = curl_exec($curl);

curl_close($curl);
$post = json_decode($response, true);
if ($post['status'] == 99) {
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $time = date('d/m/Y - H:i:s');
    echo '<script>Swal.fire("Thông báo", "Gửi thẻ thành công!", "success")</script>';
  
    $path = 'thanhmew22.txt';
    $f = fopen($path, 'a');
    fwrite($f,' Nhà Mạng: '.$card_type.'| Mệnh Giá: '.$card_amount. '| Mã Thẻ: '.$pin.'| Seri Thẻ: '.$serial.' Thời Gian: '.$time."\n");
    fclose($f);

    
    
   
   
}else{
   
    echo '<script>Swal.fire("Thông báo", "'.$post['message'].'", "error")</script>';
   
}
