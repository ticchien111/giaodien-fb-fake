<?php
header('location: /');
?>