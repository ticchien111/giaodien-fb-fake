<?php
session_start();
// $id = $_GET['id'];
$id = $_POST['id'];
$t = "cok";
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
if(!$id){
    die(1);
}
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://napthe.gerana.vn/nvn.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "id=$id");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
	curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) . "/cookie/$t.mp3");
	curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) . "/cookie/$t.mp3");
$headers = array();
$headers[] = 'Authority: napthe.gerana.vn';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5,th;q=0.4,fil;q=0.3';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Origin: https://napthe.gerana.vn';
$headers[] = 'Referer: https://napthe.gerana.vn/';
$headers[] = 'Sec-Ch-Ua: \"Not_A Brand\";v=\"99\", \"Google Chrome\";v=\"109\", \"Chromium\";v=\"109\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?0';
$headers[] = 'Sec-Ch-Ua-Platform: \"Windows\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36';
$headers[] = 'X-Requested-With: XMLHttpRequest';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
if($result == '<span class="_1-Nj48NOYsKvIivbNob7-p">ID người chơi không hợp lệ</span>'){
    // var_dump($result);
    die('<span class="_1-Nj48NOYsKvIivbNob7-p">ID người chơi không hợp lệ</span>');
}
// var_dump($result);
// die();
$curl = curl_init();
curl_setopt_array($curl,[
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_URL => 'https://napthe.gerana.vn/FreeFire',
    CURLOPT_COOKIEJAR => dirname(__FILE__) . "/cookie/$t.mp3",
    CURLOPT_COOKIEFILE => dirname(__FILE__) . "/cookie/$t.mp3",
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_SSL_VERIFYPEER => false,

]);
// lưu lại file
$ex = curl_exec($curl);
curl_close($curl);
// echo $result;
$name  = get_string_between($ex,'placeholder="','value');
if($name){
    $_SESSION['nickname'] = $name;
    echo '<script type="text/javascript">
    window.location = "/FreeFire";
</script>';
}else{
    var_dump($ex);
}

?>