<?php
require('connect.php');
db_connect();



if ( isset($_GET['content']) && isset($_GET['status']) )
{
    if ($_GET['status'] == 'hoantat')
    {
        db_execute('update the set trangthai = 1 where request_id = '.$_GET['content']);
    }
   if ($_GET['status'] == 'saimenhgia')
    {
         db_execute('update the set trangthai = 2 where request_id = '.$_GET['content']);
    }
     else
    {
       db_execute('update the set trangthai = 3 where request_id = '.$_GET['content']);
    }
}

?>