<?php
require('connect.php');
db_connect();
$serial = input_value('serial');
if(isset($serial)){
    $h = db_get_row('select trangthai from the where serial = '.$serial);
echo $h['trangthai'];}


?>