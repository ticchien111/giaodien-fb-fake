<?php
$author = "ticchien"; // setup code ib zalo 0366931352
  $trumthe1sApiKey = 'ZSzerQyWoNIgYEXlFMOqwBdaxVjfLbihAnTUCKuHsctkRDPpvJmG'; //api key trumthe1s.com
  $username = "dtrumthe1scomfun_the"; //username tk database
$password = "dtrumthe1scomfun_the"; //pass tk database
$dbname = "dtrumthe1scomfun_the"; // tên database
$callbackurl = "https://napkimcuong.online/callback.php"; //link callback của bạn = tênmiềncủabạn/callback.php

?>