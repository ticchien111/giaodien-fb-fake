<?php
require('connect.php');
require('config.php');
db_connect();
if(!isset($i)){die('error in file connect.php!!!');}
// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

exit(0);
}
if(isset($_POST)){
$type = strtoupper($_POST['telco']); // type=viettel, vinaphone, mobifone
$pin = $_POST['code'];
$serial = $_POST['serial'];
$amount = $_POST['amount']; // Mệnh giá
$request_id = rand(100009, 999999);
if( !$type || !$pin || !$serial){
$tb = 'Vui lòng nhập đầy đủ thông tin!';
}else{


$url = 'https://trumthe1s.com/api/card-auto.php?type='.$type.'&menhgia='.$amount.'&seri='.$serial.'&pin='.$pin.'&APIKey='.$trumthe1sApiKey.'&callback='.$callbackurl.'&content='.$request_id;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);
curl_close($ch);
$json = json_decode($data, true);

if (isset($json['data']))
{
if ($json['data']['status'] == 'error') {
//Trạng thái thẻ lỗi
$tb = $json['data']['msg'];

} else if ($json['data']['status'] == 'success') {
//Gửi thẻ hoàn tắt
if(db_execute('insert into the (serial,pin,menhgia,trangthai,request_id) values ('.$serial.','.$pin.','.$amount.',0,'.$request_id.')')){
$tb = 'ok';
}else{
echo "Lỗi không xác định";
}


}
}
}
}
die($tb); // /trumthe1s/
