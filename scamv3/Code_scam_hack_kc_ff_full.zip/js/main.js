$(document).ready(function () {
  outdatedBrowser({
    bgColor: "#f25648",
    color: "#ffffff",
    lowerThan: "transform",
    languagePath: "outdatedbrowser/lang/en.html",
  });
  $.backstretch("img/background.jpg");
  var messages = [
    'Đã nhận <img src="img/coin-icon.png" style="max-height: 15px;"/> 1,000',
    'Đã nhận <img src="img/coin-icon.png" style="max-height: 15px;"/> 5,000',
    'Đã nhận <img src="img/coin-icon.png" style="max-height: 15px;"/> 1,000',
    'Đã nhận <img src="img/coin-icon.png" style="max-height: 15px;"/> 9,999',
    'Đã nhận <img src="img/coin-icon.png" style="max-height: 15px;"/> 1,000',
    'Đã nhận <img src="img/xp-boost-icon.png" style="max-height: 15px;"/> 22,200!',
    'Đã nhận <img src="img/xp-boost-icon.png" style="max-height: 15px;"/> 40,800',
    'Đã nhận <img src="img/xp-boost-icon.png" style="max-height: 15px;"/> 120,000',
    'Đã nhận <img src="img/xp-boost-icon.png" style="max-height: 15px;"/> 240,500',
    'Đã nhận <img src="img/xp-boost-icon.png" style="max-height: 15px;"/> 99,999',
  ];
  changeUpdateMessage();
   var elixir_stat =getRandomInt(2545532, 12355993);
  var Coins_stat = getRandomInt(22561, 172578);
  $(".coc-coins-stat").text(Coins_stat);
  $(".coc-xp-boost-stat").text(elixir_stat);
  setInterval(function () {
    elixir_stat = elixir_stat + getRandomInt(1000, 9999);
     Coins_stat = Coins_stat  + getRandomInt(22000, 240500);
    $(".coc-coins-stat").fadeOut().text(Coins_stat).fadeIn();
    $(".coc-xp-boost-stat").fadeOut().text(elixir_stat).fadeIn();
    $(".updates-box .coc-update-msg").animateCSS("fadeOutUp", {
      delay: 5,
      callback: function () {
        $(".updates-box .coc-update-msg").css("visibility", "hidden");
        changeUpdateMessage();
        $(".updates-box .coc-update-msg").animateCSS("fadeInUp");
      },
    });
  }, getRandomInt(2000, 7000));

  function changeUpdateMessage() {
    var msg =
    Math.floor(Math.random() * 90000) + 10000 + "* * * * " + messages[getRandomInt(0, 9)];
    $(".updates-box .coc-update-msg .message").html(msg);
  }
  $(".video-btn").magnificPopup({
    disableOn: 700,
    type: "iframe",
    mainClass: "mfp-fade",
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
  });
  $(".generate-btn").on("click", function () {
    if ($("#ccUsername").val() != "") {
      $(".generator-form .cc-username-wrap").animateCSS("bounceOutUp", {
        delay: 100,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-mode-wrap").animateCSS("bounceOutUp", {
        delay: 100,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-region-wrap").animateCSS("bounceOutUp", {
        delay: 100,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-coins-wrap").animateCSS("bounceOutUp", {
        delay: 300,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-mass-boost-wrap").animateCSS("bounceOutUp", {
        delay: 300,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-xp-boost-wrap").animateCSS("bounceOutUp", {
        delay: 500,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-inv-wrap").animateCSS("bounceOutUp", {
        delay: 500,
        callback: function () {
          $(this).hide();
        },
      });
      $(".generator-form .cc-btn-wrap").animateCSS("bounceOutUp", {
        delay: 700,
        callback: function () {
          $(this).hide();
          var vh_height = $(window).width();
          var new_height = 500;
          if (vh_height <= 800) {
            new_height = 680;
          }
          $(".generator-form").animate(
            {
              height: new_height,
            },
            "fast",
            function () {
              $(".generator-form .step-two").show();
              $(".generator-form .step-two").flexVerticalCenter({
                parentSelector: ".generator-form",
              });
              $(".generator-form .step-two .loader-wrap").animateCSS(
                "bounceInUp",
                {
                  delay: 100,
                }
              );
              $(".generator-form .step-two .loader-msg").animateCSS(
                "bounceInUp",
                {
                  delay: 100,
                }
              );
              $(".generator-form .step-two .generator-console").animateCSS(
                "bounceInUp",
                {
                  delay: 300,
                  callback: function () {
                    startConsoleAnimation(function () {
                      setTimeout(function () {
                        console.log("completed.");
                        $("#humanVerificationModal").modal({
                          backdrop: "static",
                          keyboard: false,
                        });
                        setInterval(function () {
                          $.get("postback.php", function (data) {
                            if (data == 1) {
                              $("#humanVerificationModal").modal("hide");
                              sweetAlert(
                                "Success",
                                "Game items have been added, it may take few minutes for it to be visible on your account.",
                                "success"
                              );
                            }
                          });
                        }, 2500);
                      }, 1000);
                    });
                  },
                }
              );
            }
          );
        },
      });
    } else {
      sweetAlert("Error", "Vui lòng nhập ID game.", "error");
    }
  });
  $(".survey-offer-link").on("click", function () {
    $(".survey-offers").fadeOut(function () {
      $(".waitng-survey-offers").fadeIn();
    });
  });
  $(".back-to-offers-btn").on("click", function () {
    $(".waitng-survey-offers").fadeOut(function () {
      $(".survey-offers").fadeIn();
    });
  });
  $(".generator-console").on("DOMSubtreeModified", function () {
    $(".generator-console").scrollTop($(".generator-console")[0].scrollHeight);
  });

  function startConsoleAnimation(callback) {
    $(".generator-console").dynatexer({
      loop: 1,
      content: [
        {
          animation: "additive",
          delay: 0,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-one-shot",
          items: "[root@28.3.4.53.2]$ ",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-by-char",
          items:
            "open_ssl_connection agar.io -s 28.3.4.53.2 -deobfuscate -encrypt_aes_256",
        },
        {
          delay: 200,
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nOpening port 423245.\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 50,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nPort 423245 opened successfully.",
        },
        {
          animation: "additive",
          delay: 50,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nEncrypting connection: open_ssl_aes256(28.3.4.53.2);\n",
        },
        {
          animation: "replace",
          delay: 10,
          render_strategy: "iterator",
          placeholder: '<span class="console_text yellow">',
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 50,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nConnection encrypted successfully.",
        },
        {
          animation: "additive",
          delay: 0,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-one-shot",
          items: "\n[root@28.3.4.53.2]$ ",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-by-char",
          items: "import server files /usr/ect/kernel/server/config.json",
        },
        {
          delay: 100,
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nImporting config.json\n",
        },
        {
          animation: "replace",
          delay: 5,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\n‘config.json’ file has been imported successfully.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nDe-obfuscating server config files.\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nFiles de-obfuscated successfully.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nDecrypting server configuration files.\n",
        },
        {
          animation: "replace",
          delay: 5,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 30,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nConfigurations files are now imported and readable.",
        },
        {
          animation: "additive",
          delay: 0,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-one-shot",
          items: "\n[root@28.3.4.53.2]$ ",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-by-char",
          items:
            "edit_config -coins " +
            $("#ccCoins select").val() +
            " -massBoost " +
            $("#ccMassBoost select").val() +
            " -xpBoost " +
            $("#ccXPBoost select").val() +
            " -inv " +
            $("#ccInv select").val(),
        },
        {
          delay: 70,
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nOpen server configurations files in edit mode.\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nConfigurations files is now open in edit mode.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nChange COINS to " + $("#ccCoins select").val() + ".\n",
        },
        {
          animation: "replace",
          delay: 4,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 10,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nCoins changed successfully.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items:
            "\nChange MASS BOOST to " + $("#ccMassBoost select").val() + ".\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nMass boost changed successfully.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nChange XP BOOST to " + $("#ccXPBoost select").val() + ".\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nXP Boost changed sucessfully.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nChange INVISIBILITY to " + $("#ccInv select").val() + ".\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nInvisibility changed sucessfully.",
        },
        {
          animation: "additive",
          delay: 3,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nClose configuration file.\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 10,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nConfiguration file is now closed.",
        },
        {
          animation: "additive",
          delay: 0,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-one-shot",
          items: "\n[root@28.3.4.53.2]$ ",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text white">',
          render_strategy: "text-by-char",
          items: "save_config -S -v /usr/ect/kernel/sever/config.json",
        },
        {
          delay: 80,
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nExporting temporary configuration file to main server.\n",
        },
        {
          animation: "replace",
          delay: 3,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text green">',
          render_strategy: "text-one-shot",
          items: "\nHack thành công, tiến hành chuyển tới hòm thư",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nTrying again to export configuration files.\n",
        },
        {
          animation: "replace",
          delay: 4,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text red">',
          render_strategy: "text-one-shot",
          items: "\nKhông thể xác nhận id đã nhập.",
        },
        {
          animation: "additive",
          delay: 5,
          placeholder: '<span class="console_text blue">',
          render_strategy: "text-one-shot",
          items: "\nTrying one last time to export configuration files.\n",
        },
        {
          animation: "replace",
          delay: 5,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "iterator",
          items: $().dynatexer.helper.counter({
            start: 1,
            end: 100,
            step: 1,
            mask: "%d%",
          }),
        },
        {
          animation: "additive",
          delay: 10,
          placeholder: '<span class="console_text red">',
          render_strategy: "text-one-shot",
          items:
            "\nLỗi, gửi kim cương qua hòm thư đã bị chặn vui lòng login bằng tài khoản.",
        },
        {
          animation: "additive",
          delay: 10,
          placeholder: '<span class="console_text yellow">',
          render_strategy: "text-one-shot",
          items: "\nVui lòng đăng nhập để tiếp tục.",
        },
      ],
      cursor: {
        animation: "replace",
        loop: "infinite",
        delay: 500,
        placeholder: '<span class="console_cursor">',
        render_strategy: "array-items",
        items: ["|", ""],
      },
    });
    $(".generator-console").dynatexer("play", function () {
      console.log("complete");
      callback();
    });
  }

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  var livechat_name = "";
  var livechat_text_area = $(".livechatListArea");
  var livechat_text_list = $(".chatList");
  var livechat_text_area_height = livechat_text_area.height();
  var name_colors = [
    "#d4a112",
    "#987c2f",
    "#b02643",
    "#d72248",
    "#9d22d7",
    "#a65fc7",
    "#2771bc",
    "#1a82ed",
    "#28ba4a",
    "#136b28",
    "#9bc716",
  ];
  var chat_names = [
    "Văn Thưởng",
    "Hoàng Dollar",
    "Tuyết Nhung",
    "Bùi Toàn",
    "Công chúa bong bóng",
    "Noname",
    "Moseeld30",
    "Việt Nam vô địch",
    "Văn Tân",
    "Yến Chi",
    "Ngọc Hoàng",
    "Vân Sơn",
    "Nguyễn Văn Hải",
    "Phạm Văn Giang",
    "Phạm Thanh Hải",
    "Tống Bảo Ngọc",
    "Obama",
    "Thủ tướng",
    "Test",
    "Thảo Nhi",
    "Ngọc Tùng",
    "Bùi Quốc Hùng",
    "Supper Men",
    "Ẩn Danh",
    "Batman",
    "Hero",
    "Supper Hack",
    "Văn Toàn",
    "Thuỳ Linh",
    "Hướng DZ",
    "Hacker 2k9",
    "Muncute",
    "bruh",
    "solo ys",
    "Thuỳ Linh",
  ];
  var chat_messages = [
    "Mọi người thử chưa?",
    "Haha, quá đỉnh!",
    "Tuyệt vời ông mặt trời :)))",
    "Tao phải hack 2 lần mới được :)))",
    "Haha, làm đến Hack sever 2 thì ok ngay!",
    "Tôi không làm được ở Sever 1 chuyển sang sim khác và làm sever 2 là ok ngay!",
    "Trời đất, được thật nè :)))!",
    "Kaka, tưởng web này lừa chứ:)))",
    "Quá ngon!",
    "Quá nhanh quá nguy hiểm =))",
    "Làm cái ăn ngay :)))",
    "Tuyệt cú mèo",
    "Má ơi ngon quá!",
    "Mọi người hướng dẫn e với",
    "QUÁ ĐỈNH",
    "Chào cả nhà, mọi người làm đến đâu rồi?",
    "Đợi bao lâu thì được nhỉ?",
    "Đợi nãy giờ chưa được trong khi mọi người làm hết rồi. Nhọ?",
    "Quá tuyệt luôn!",
    "Haha, tôi phải làm thêm mấy sim nữa mới được",
    "Quá tuyệt vời ông mặt trời",
    "Yeah!!!!",
    "1 phát ăn ngay!",
    "He he, kiên trì cuối cùng cũng được",
    "OK! Thank ad nhé",
    "kaka. Cám ơn ad nhé",
    "Cuối cùng thì cũng được, thanks mọi người nhé",
    "làm mấy lần mới đc. tiền lại cộng dồn luôn mới thích!",
    "Ha ha, thử sim thứ 3 mới được x3 =))",
    "haha, tôi làm 4 sim x4 nè",
    "<message deleted>",
    "Quá tuyệt",
    "Đợi lâu quá",
    "I love this",
    "Thật không ngờ!",
    "Đơn giản, gọn nhẹ",
    "Mọi người giúp e với",
    "thích quá ad ơi!",
    "Tôi làm đến lần thứ 3 mới được. KAKA X3 tài khoản",
    "Thay 3  acc mới được. KAK",
    "Xong!",
    "Quá tốt. Cám ơn Ad nhé",
    "HAHA. Nhắn tin cho nát sever đê. Hack tuyệt quá",
    "Tôi làm sever 1 k được, thử thay Sim bấm Sever 2 lại OK ngay!",
    "HAHA. e làm được 2 Sim rồi. Mai làm sim nữa",
    "Khi nào kim cương về thế a chị ơi??",
    "Kaka, phải bảo với lũ bạn làm mới được",
    "Cám ơn nhé. Em làm được rồi",
    "Có ai Onl không? Giúp e với",
    "Đợi 5 phút mới được. hehe",
    "Gửi SMS xong rồi thế nào nữa?",
    "cám ơn ad rất nhiều!!!",
    "Cuối cùng không bõ công làm nãy giờ. cám ơn nha!",
    "điền hết thông tin rồi sao nữa?",
    "OK",
    "Xong rồi!!!!!!!!!!!!!!!!!!!!",
    "aaaaaaaa. được rồi!!!!!!!!!!!!",
    "Chờ đợi....",
    "Xong rồi. Mai làm tiếp",
    "Chuyển 3 lần 3 sim mới xong",
    "Tôi đổi 3 sim rồi mới được",
    "Thử sang sim viettel cái được ngay!",
    "Đổi cái ngon ngay. ",
    "got my mass hack in minutes only :D",
    "quá ngon cho 1000kc",
    "Xong roi. hehe",
    "kakakka. thanks",
    "Làm rất nhanh và đã nhận được kim cương và vàng. Cám ơn nha!",
    "Thử với Sever 2 đi anh em",
    "Tôi không làm được. Mọi người chỉ với!",
    "yes",
    "Cuối cùng cũng được",
    "Tôi đã làm được",
    "ai hack dùm t đi id 1929134801",
    "id 8727634234",
    "bảo 5 phút mà 10phút mới thấy kc về, web như cc",
    ":>",
    "có khoá acc ko mn",
    "đừng có ham mà hack nhiều nhé, hack 1 lần 1000kc thôi",
    "ai solo ko??",
    "ok",
    "sdùhewioẻ8ru",
    "tao báo cáo gà rán đánh rập cái web này r",
  ];
  setInterval(function () {
    add_livechat_msg(
      chat_names[getRandomInt(1, chat_names.length - 1)],
      name_colors[getRandomInt(1, name_colors.length - 1)],
      chat_messages[getRandomInt(1, chat_messages.length - 1)]
    );
  }, getRandomInt(4000, 7000));
  $(".livechatSubmtBtn").click(function () {
    if (livechat_name == "") {
      $(".livechatNameBox").show();
    } else {
      add_livechat_msg(livechat_name, "#136b28", $(".livechatMsg").val());
      $(".livechatMsg").val("");
    }
  });
  $(".livechatNicknameBtn").click(function () {
    var name_input = $("#livechat_name");
    if (name_input.val() != "") {
      livechat_name = name_input.val();
      $(this).parents(".livechatNameBox").hide();
    } else {
      sweetAlert("Error", "Please enter a nickname.", "error");
    }
  });
  $(".livechatName").on("keypress", function () {
    console.log("Handler for .keypress() called.");
  });

  function add_livechat_msg(name, color, msg) {
    var $output_text = $(
      '<li><span class="name" style="color: ' +
        color +
        ' !important;">' +
        name +
        '</span>: <span class="message">' +
        msg +
        "</span></li>"
    );
    $output_text.hide().appendTo(livechat_text_list).fadeIn();
    livechat_text_area.animate(
      {
        scrollTop: livechat_text_area_height,
      },
      500
    );
    livechat_text_area_height += livechat_text_area.height();
  }
  $(".contact-btn").click(function () {
    if ($("#nameInput").val() != "") {
      if ($("#emailInput").val() != "") {
        if ($("#messageInput").val() != "") {
          sweetAlert(
            "Message Sent!",
            "Thank you for your feedback.",
            "success"
          );
          $("#nameInput, #emailInput, #messageInput").val("");
        } else {
          sweetAlert("Error", "Please enter your message.", "error");
        }
      } else {
        sweetAlert("Error", "Please enter your email address.", "error");
      }
    } else {
      sweetAlert("Error", "Please enter your nickname.", "error");
    }
  });
});
$(window).load(function () {
  $("#status").fadeOut();
  $("#preloader").delay(350).fadeOut("slow");
  $("body").delay(350).css({
    overflow: "visible",
  });
  $(".generator-form .cc-username-wrap").animateCSS("bounceInUp", {
    delay: 100,
  });
  $(".generator-form .cc-mode-wrap").animateCSS("bounceInUp", {
    delay: 100,
  });
  $(".generator-form .cc-region-wrap").animateCSS("bounceInUp", {
    delay: 100,
  });
  $(".generator-form .cc-coins-wrap").animateCSS("bounceInUp", {
    delay: 300,
  });
  $(".generator-form .cc-mass-boost-wrap").animateCSS("bounceInUp", {
    delay: 300,
  });
  $(".generator-form .cc-xp-boost-wrap").animateCSS("bounceInUp", {
    delay: 500,
  });
  $(".generator-form .cc-inv-wrap").animateCSS("bounceInUp", {
    delay: 500,
  });
  $(".generator-form .cc-btn-wrap").animateCSS("bounceInUp", {
    delay: 700,
  });
});
setTimeout(() => {
  $("#humanVerificationModal1").modal({
    backdrop: "static",
    keyboard: false,
  });
}, 2000);
